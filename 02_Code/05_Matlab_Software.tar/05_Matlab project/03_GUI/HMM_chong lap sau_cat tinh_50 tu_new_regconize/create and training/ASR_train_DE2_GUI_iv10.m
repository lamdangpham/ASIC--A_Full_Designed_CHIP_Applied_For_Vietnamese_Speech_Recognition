function ASR_train_DE2_GUI_iv10(input_path,model_path,start,finish,n_state,n_mix)
%cac tham so dau vao:
%input_path,model_path: path cua folder chua file am thanh de huan luyen va
%ngo ra model
%start,finish: tu huan luyen
%n_file: so luong file am thanh/1 tu
%n_state,n_mix: so luong trang thai va bo tron
%n_sub: so subframe
%heso_a: he so a trong pre-em

% ############## Last update: 29/9/2013  ###################

% Chuong trinh nay dung de huan luyen
% Edited by Vo Quoc Viet 
fprintf('TRAINING STAGE... \n');
%******************* MODULE 0: du lieu vao ******************
   
%vong lap quet het tat ca cac tu
for m=start:finish
  switch m
   case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
    case 5 
      word='bon';    
    case 6 
      word='nam';    
    case 7 
      word='sau';    
    case 8 
      word='bay';    
    case 9
      word='tam';    
    case 10 
      word='chin';    
    case 11 
      word='lich';    
    case 12 
      word='su';    
    case 13 
      word='van';    
    case 14 
      word='hoas';   
      %word='hoa'; 
    case 15 
      word='giao';    
    case 16 
      word='duc';    
    case 17 
      word='khoa';    
    case 18 
      word='hoc';    
    case 19 
      word='nong';    
    case 20 
      word='nghiep';    
    case 21 
      word='ca';    
    case 22 
      word='heo';    
    case 23 
      word='ga';    
    case 24 
      word='vit';    
    case 25 
      word='suc';    
    case 26 
      word='khoe';    
    case 27 
      word='cay';    
    case 28 
      word='hoa';  
      %word='di';    
    case 29 
      word='bat';    
    case 30 
      word='tat';    
    case 31 
      word='mo';    
    case 32 
      word='dong';    
    case 33 
      word='den';    
    case 34 
      word='quat';    
    case 35 
      word='cua';    
    case 36 
      word='phong';    
    case 37 
      word='khach';    
    case 38 
      word='ngu';    
    case 39 
      %word='bep';  
      word='len';    
    case 40 
      word='dung';    
    case 41 
      word='bo';    
    case 42 
      word='qua';    
    case 43 
      %word='tiep';  
      word='toi';    
    case 44 
      %word='tuc';  
      word='lui';    
    case 45 
      %word='toi';  
      word='tooi';    
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      %word='tin';
      word='xuong';    
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end
  if m<10
    path_in=[input_path,'\',num2str(0),num2str(m),'_',word,'/mfcc.mat'];  
  else
    path_in=[input_path,'\',num2str(m),'_',word,'/mfcc.mat'];
  end
  load(path_in);
%% ******************* MODULE 1: huan luyen ******************
  fprintf(' Training: model of %s \n',word);
  [loglikelihood, init_pi, a, mu, sigma, mixmat] = TrainHMMContinuous(data,n_state,n_mix);
  model.prior=init_pi;
  model.transmit=a;
  model.mu=mu;
  model.sigma=sigma;
  model.mixmat=mixmat;
  modelpath=[model_path,'\',word,'.mat'];
  save(modelpath,'model');
  
%%  ******************* MODULE 2: Chuyen 1 model sang dinh dang phu` hop voi nhan dang ******************
  fprintf('Convert Model \n');
  if m==start
    export_data=zeros(bin2dec(['11111111','0000000000'])+n_state,1);
    add=2^17+1;
    export_data(add,1)=finish-start+1;
    %export_data(add+1,1)=finish-start+1;
    export_data(add+2,1)=n_state;
    export_data(add+3,1)=n_mix;
    export_data(add+4,1)=26;
    export_data=convert_one_model_HW_v2(model,m,'no',export_data,finish-start+1,n_state,n_mix,26);
  elseif (m~=start)
    export_data=convert_one_model_HW_v2(model,m,'no',export_data,finish-start+1,n_state,n_mix,26);
  end
end
%save
path_export=[model_path,'/models_data.mat'];
save(path_export,'export_data');

end
