function varargout = TRAININGPROGRAM_iv9(varargin)
% TRAININGPROGRAM_iv9 M-file for TRAININGPROGRAM_iv9.fig
%      TRAININGPROGRAM_iv9, by itself, creates a new TRAININGPROGRAM_iv9 or raises the existing
%      singleton*.
%
%      H = TRAININGPROGRAM_iv9 returns the handle to a new TRAININGPROGRAM_iv9 or the handle to
%      the existing singleton*.
%
%      TRAININGPROGRAM_iv9('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRAININGPROGRAM_iv9.M with the given input arguments.
%
%      TRAININGPROGRAM_iv9('Property','Value',...) creates a new TRAININGPROGRAM_iv9 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TRAININGPROGRAM_iv9_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TRAININGPROGRAM_iv9_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help TRAININGPROGRAM_iv9

% Last Modified by Vo Quoc Viet v2.5 12-Sep-2012 17:44:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TRAININGPROGRAM_iv9_OpeningFcn, ...
                   'gui_OutputFcn',  @TRAININGPROGRAM_iv9_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TRAININGPROGRAM_iv9 is made visible.
function TRAININGPROGRAM_iv9_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to TRAININGPROGRAM_iv9 (see VARARGIN)

% Choose default command line output for TRAININGPROGRAM_iv9
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes TRAININGPROGRAM_iv9 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = TRAININGPROGRAM_iv9_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in create_model.
function create_model_Callback(hObject, eventdata, handles)
% hObject    handle to create_model (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fprintf('PROCESSING...\n...\n');
global input_type;
input_path=get(handles.inputaudio,'String');%path audio in de tao model
output_path=get(handles.outputmodel,'String');%patch chua model

start = str2num(get(handles.start_word,'String'));
finish = str2num(get(handles.end_word,'String'));
n_files_train = str2num(get(handles.n_file_train,'String'));%so luong file/1 tu de huan luyen
n_states = get(handles.n_state,'Value');%so trang thai ~ so hop bi, default =8
n_mixs = get(handles.n_mix,'Value');%so bo tron ~ so bi, default =2
n_subs = get(handles.n_sub,'Value');
%so subframe ban dau cua 1 tu=> tinh nguong nang luong de cat khoang lang.
E_str = get(handles.thresh_str,'Value');
%bat dau lay frame khi nang luong gap E_str lan nang luong cua nhieu/khaong
%lang
E_end = get(handles.thresh_end,'Value');
%Diem cuoi - tam thoi ko xai
n_sub_co_nghia=get(handles.so_sub_co_nghia,'Value');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
heso_a=get(handles.a,'String');%he so a cho khoi pre-em, nhieu cung dc
n_a=length(heso_a);
flag=0;
for j=1:n_a %xd xem '/' nam o dau trong chuoi n_a
    if heso_a(j)=='/'
        flag=j;
    end
end
if flag~=0%neu chuoi n_a co '/'
    TS=str2num(heso_a(1:flag-1));%lay tu so cua n_a
    MS=str2num(heso_a(flag+1:n_a));%lay mau so cua n_a
    hs_a=TS/MS;%=> tinh hs_a
    fprintf('flag = %d \n TS = %d \n MS = %d \n he so a = %2.5f \n',flag,TS, MS, hs_a);
else hs_a=str2num(heso_a);
end
fprintf('he so a = %2.5f \n',hs_a);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%doan code tren: neu a la so nguyen => chuyen doi truc tiep str->num
%                neu a la so huu ty => xd tu so, mau sao => tinh hs_a=TS/MS
%Neu TS va MS ko de lam gi => co the dung cau lenh truc tiep
%heso_a=num2str(get(handles.a,'String'));

%set cac truong hop default
if n_states==1
    n_states=8;
end 
if n_mixs==1
    n_mixs=2;
end
if n_subs==1
    n_subs=16;
end
if n_sub_co_nghia==1
    n_sub_co_nghia=20;
end
if E_str==1
    E_str=10;
end
if E_end==1
    E_end=3;
end


disp(input_path);
disp(output_path);
%disp(n_words);
disp(n_files_train);

disp(n_states);
disp(n_mixs);
disp(n_subs);
disp(E_str);
disp(E_end);
disp(n_sub_co_nghia);
%ASR_train_DE2_GUI_iv6(input_path,output_path,n_words,n_files_train,n_states,n_mixs,E_str,E_end,n_subs,hs_a);

ASR_train_DE2_GUI_iv9(input_path,output_path,start,finish,n_files_train,n_states,n_mixs,E_str,E_end,n_subs,hs_a,input_type);
fprintf('COMPLETED. \n');


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text2.
function text2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function outputmodel_Callback(hObject, eventdata, handles)
% hObject    handle to outputmodel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of outputmodel as text
%        str2double(get(hObject,'String')) returns contents of outputmodel as a double


% --- Executes during object creation, after setting all properties.
function outputmodel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outputmodel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function n_file_Callback(hObject, eventdata, handles)
% hObject    handle to n_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n_file as text
%        str2double(get(hObject,'String')) returns contents of n_file as a double


% --- Executes during object creation, after setting all properties.
function n_file_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in n_mix.
function n_mix_Callback(hObject, eventdata, handles)
% hObject    handle to n_mix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns n_mix contents as cell array
%        contents{get(hObject,'Value')} returns selected item from n_mix


% --- Executes during object creation, after setting all properties.
function n_mix_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_mix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in n_state.
function n_state_Callback(hObject, eventdata, handles)
% hObject    handle to n_state (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns n_state contents as cell array
%        contents{get(hObject,'Value')} returns selected item from n_state


% --- Executes during object creation, after setting all properties.
function n_state_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_state (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in thresh_end.
function thresh_end_Callback(hObject, eventdata, handles)
% hObject    handle to thresh_end (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns thresh_end contents as cell array
%        contents{get(hObject,'Value')} returns selected item from thresh_end


% --- Executes during object creation, after setting all properties.
function thresh_end_CreateFcn(hObject, eventdata, handles)
% hObject    handle to thresh_end (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in thresh_str.
function thresh_str_Callback(hObject, eventdata, handles)
% hObject    handle to thresh_str (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns thresh_str contents as cell array
%        contents{get(hObject,'Value')} returns selected item from thresh_str


% --- Executes during object creation, after setting all properties.
function thresh_str_CreateFcn(hObject, eventdata, handles)
% hObject    handle to thresh_str (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in n_sub.
function n_sub_Callback(hObject, eventdata, handles)
% hObject    handle to n_sub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns n_sub contents as cell array
%        contents{get(hObject,'Value')} returns selected item from n_sub


% --- Executes during object creation, after setting all properties.
function n_sub_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_sub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on key press with focus on n_mix and none of its controls.
n
% hObject    handle to n_mix (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)



function inputaudio_Callback(hObject, eventdata, handles)
% hObject    handle to inputaudio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inputaudio as text
%        str2double(get(hObject,'String')) returns contents of inputaudio as a double


% --- Executes during object creation, after setting all properties.
function inputaudio_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inputaudio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function start_word_Callback(hObject, eventdata, handles)
% hObject    handle to start_word (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of start_word as text
%        str2double(get(hObject,'String')) returns contents of start_word as a double


% --- Executes during object creation, after setting all properties.
function start_word_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start_word (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on n_mix and none of its controls.
function n_mix_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to n_mix (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in check_model.
function check_model_Callback(hObject, eventdata, handles)
% hObject    handle to check_model (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%set(handles.ketqua,'String',['PROCCESING...']);
global input_type;
fprintf('PROCESSING...\n ...\n');
input_test=get(handles.input_test,'String');%path chua file am thanh muon test
output_path=get(handles.outputmodel,'String');
%input_tests=get(handles.input_test,'String');
start = str2num(get(handles.start_word,'String'));
finish = str2num(get(handles.end_word,'String'));
n_files = str2num(get(handles.n_file,'String'));%so file wav/1 tu

n_subs = get(handles.n_sub,'Value');
E_str = get(handles.thresh_str,'Value');
E_end = get(handles.thresh_end,'Value');
n_sub_co_nghia=get(handles.so_sub_co_nghia,'Value');%so subframe co y nghia cua 1 tu
heso_a=get(handles.a,'String');
n_a=length(heso_a);
flag=0;
for j=1:n_a
    if heso_a(j)=='/'
        flag=j;
    end
end
if flag~=0
    TS=str2num(heso_a(1:flag-1));
    MS=str2num(heso_a(flag+1:n_a));
    hs_a=TS/MS;
    fprintf('flag = %d \n TS = %d \n MS = %d \n he so a = %2.5f \n',flag,TS, MS, hs_a);
else hs_a=str2num(heso_a);
end
if n_subs==1
    n_subs=16;
end
if n_sub_co_nghia==1
    n_sub_co_nghia=20;
end
if E_str==1
    E_str=10;
end
if E_end==1
    E_end=3;
end
disp(input_test);
disp(output_path);
%disp(n_words);
disp(n_files);

disp(n_sub_co_nghia);
disp(E_str);
disp(E_end);
%sx=ASR_rec_DE2_GUI_iv6(input_test,output_path,start,finish,n_files,E_str,E_end,n_subs,hs_a,input_type);
%sx=ASR_rec_DE2_GUI_iv9(input_test,output_path,n_words,n_files,E_str,E_end,n_subs,hs_a);
sx=ASR_rec_DE2_GUI_iv7(input_test,output_path,start,finish,n_files,E_str,E_end,n_subs,hs_a,input_type);
set(handles.so_tu_test,'String',['So luong mau duoc test: ',num2str(n_files*(finish-start+1))]);
set(handles.ketqua,'String',['Sac xuat nhan dang: ',num2str(sx),'%']);
%set(handles.ketqua,'String',['PROCCESING...']);
fprintf('DA NHAN DANG XONG \n');

function input_test_Callback(hObject, eventdata, handles)
% hObject    handle to input_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of input_test as text
%        str2double(get(hObject,'String')) returns contents of input_test as a double


% --- Executes during object creation, after setting all properties.
function input_test_CreateFcn(hObject, eventdata, handles)
% hObject    handle to input_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function n_file_train_Callback(hObject, eventdata, handles)
% hObject    handle to n_file_train (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n_file_train as text
%        str2double(get(hObject,'String')) returns contents of n_file_train as a double


% --- Executes during object creation, after setting all properties.
function n_file_train_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_file_train (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
output_path=get(handles.outputmodel,'String');
convert_model_path=get(handles.convert_model_path,'String');
filename = get(handles.filename,'String');
start = str2num(get(handles.start_word,'String'));
finish = str2num(get(handles.end_word,'String'))
%n_words = str2num(get(handles.start_word,'String'));
n_states = get(handles.n_state,'Value');
n_mixs = get(handles.n_mix,'Value');
shift_c=12;
shift_d=0;
shift_num=15;
if n_states==1
    n_states=8;
end
if n_mixs==1
    n_mixs=2;
end
%tao_tham_so_fix_DE2_GUI_v5(output_path,convert_model_path,filename,n_states-1,n_mixs-1,shift_c,shift_d,shift_num,n_words);
test_tao_tham_so_fix_DE2_GUI_v5(output_path,convert_model_path,filename,n_states-1,n_mixs-1,shift_c,shift_d,shift_num,start,finish);
disp(convert_model_path);
disp(output_path);
disp(filename);
disp(' ');
%tao_tham_so_fix_DE2_GUI_v4(output_path,convert_model_path,filename);

%disp(n_words);
disp(n_states);
disp(n_mixs);

fprintf('COMPLETED CONVERTING MODEL...\n');





% --- Executes on selection change in so_sub_co_nghia.
function so_sub_co_nghia_Callback(hObject, eventdata, handles)
% hObject    handle to so_sub_co_nghia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns so_sub_co_nghia contents as cell array
%        contents{get(hObject,'Value')} returns selected item from so_sub_co_nghia


% --- Executes during object creation, after setting all properties.
function so_sub_co_nghia_CreateFcn(hObject, eventdata, handles)
% hObject    handle to so_sub_co_nghia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function convert_model_path_Callback(hObject, eventdata, handles)
% hObject    handle to convert_model_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of convert_model_path as text
%        str2double(get(hObject,'String')) returns contents of convert_model_path as a double


% --- Executes during object creation, after setting all properties.
function convert_model_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to convert_model_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function filename_Callback(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filename as text
%        str2double(get(hObject,'String')) returns contents of filename as a double


% --- Executes during object creation, after setting all properties.
function filename_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open('C:\Program Files\MATLAB\Helps for ASR project\HUONG DAN SU DUNG CHO ASR PROJECT.pdf');



function a_Callback(hObject, eventdata, handles)
% hObject    handle to a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of a as text
%        str2double(get(hObject,'String')) returns contents of a as a double


% --- Executes during object creation, after setting all properties.
function a_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3



function end_word_Callback(hObject, eventdata, handles)
% hObject    handle to end_word (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of end_word as text
%        str2double(get(hObject,'String')) returns contents of end_word as a double


% --- Executes during object creation, after setting all properties.
function end_word_CreateFcn(hObject, eventdata, handles)
% hObject    handle to end_word (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in wav_in.
function wav_in_Callback(hObject, eventdata, handles)
% hObject    handle to wav_in (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global input_type;
input_select=get(handles.wav_in,'value');
if input_select==1
  set(handles.binary_in,'value',0);
end
input_type='wav'
% Hint: get(hObject,'Value') returns toggle state of wav_in


% --- Executes on button press in binary_in.
function binary_in_Callback(hObject, eventdata, handles)
% hObject    handle to binary_in (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global input_type;
input_select=get(handles.binary_in,'value');
if input_select==1
  set(handles.wav_in,'value',0);
end
input_type='binary'
% Hint: get(hObject,'Value') returns toggle state of binary_in
