function ASR_train_DE2_GUI_iv9(input_path,model_path,start,finish,n_file,n_state,n_mix,thresh_str,thresh_end,n_sub,heso_a,input_type)
%cac tham so dau vao:
%input_path,model_path: path cua folder chua file am thanh de huan luyen va
%ngo ra model
%n_words: so luong tu dc huan luyen
%n_file: so luong file am thanh/1 tu
%n_state,n_mix: so luong trang thai va bo tron
%thresh_str,thresh_end: he so thresh start va end, tam thoi
%end ko su dung
%n_sub: so subframe
%heso_a: he so a trong pre-em

% ############## Last update: 29/9/2013  ###################

% Chuong trinh nay dung de huan luyen
% Edited by Vo Quoc Viet 
fprintf('TRAINING STAGE... \n');
%******************* MODULE 0: du lieu vao ******************
   
%vong lap quet het tat ca cac tu
for m=start:finish
  pos=m;
  switch m
    case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
    case 5 
      word='bon';    
    case 6 
      word='nam';    
    case 7 
      word='sau';    
    case 8 
      word='bay';    
    case 9
      word='tam';    
    case 10 
      word='chin';    
    case 11 
      word='lich';    
    case 12 
      word='su';    
    case 13 
      word='van';    
    case 14 
      word='hoa';    
    case 15 
      word='giao';    
    case 16 
      word='duc';    
    case 17 
      word='khoa';    
    case 18 
      word='hoc';    
    case 19 
      word='nong';    
    case 20 
      word='nghiep';    
    case 21 
      word='ca';    
    case 22 
      word='heo';    
    case 23 
      word='ga';    
    case 24 
      word='vit';    
    case 25 
      word='suc';    
    case 26 
      word='khoe';    
    case 27 
      word='cay';    
    case 28 
      word='di';    
    case 29 
      word='bat';    
    case 30 
      word='tat';    
    case 31 
      word='mo';    
    case 32 
      word='dong';    
    case 33 
      word='den';    
    case 34 
      word='quat';    
    case 35 
      word='cua';    
    case 36 
      word='phong';    
    case 37 
      word='khach';    
    case 38 
      word='ngu';    
    case 39 
      word='len';    
    case 40 
      word='dung';    
    case 41 
      word='bo';    
    case 42 
      word='qua';    
    case 43 
      word='toi';    
    case 44 
      word='lui';    
    case 45 
      word='tooi';    
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      word='xuong';    
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end
  for j=1:n_file
    if (strcmp(input_type,'wav'))
      path=strcat(input_path,word,'\file - huan luyen/',num2str(j),'.wav');
      disp(path);
      [x1 Fs] =wavread(path);
      x1=x1*2^15;
    else
      path=strcat(input_path,'\',word,'\file - huan luyen/',word,'_',num2str(j));
      disp(path);
      Fs=8000;                   
      file=fopen(path);
      x1=fread(file,inf,'short');
      fclose(file);
    end

        Fs = 8000;
        t=10;%t la thoi gian 1 khung cua so = 1 subframe - don vi la ms
        nwin=Fs/1000*t; % chuong trinh dung Fs=8000Hz nen nwin=80
        %soundsc(x1,Fs,16);
       % figure(19);
       % plot(x1);
            
%*******************    MODULE 1: Tien xu ly   ******************

                    %fprintf('############    1 - Energy & Detect word    ############ \n');
                   
                     nx=length(x1); 
                     x=0;
                     
                     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                     if mod(nx,nwin)>0
                                nx=fix(nx/nwin)*nwin;
                                x(1:nx+1,1)=x1(1:nx+1,1);%tai sao cong 1, vi gia tri them vao se la so 0?????
                     else
                          x(1:nx,1)=x1(1:nx,1);
                          x(nx+1,1)=x1(nx,1);%?????
                     end
                     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                     %doan code tren de lay vecto x tu x1, neu
                     %nx=length(x1) ko chia het cho nwin(so mau/1 frame) =>
                     %chinh lai nx cho chia het nwin roi lay x=x1(1:nx+1).
                     %nguoc lai, nx chia het nwin, ko sua nx, lay
                     %x=x1(1:nx) va x(nx+1)=x1(nx)?????
                     %trong qua trinh tinh energy, bo diem lay mau dau tien
                     %theo nhu thiet ke cua HW, nen can lay them 1 mau o
                     %sau lay 1:nx+1 nhug se dung tu 2:nx+1
                     %
                     
                     length_x=length(x);
                     E_sub= enerHW_DE2_iv9(x(1:length_x-2*nwin),Fs,t); %K gioi han so bit
                     
                     %trong code nay da bo qua tinh binh phuong cho gia tri dau cua data
                     %ko tinh 2 frame cuoi
                                                
                     %E_sub= enerHW_DE2_iv9(x1,Fs);
                     x_ener1=[];
                     %x_ener=[];
                     
                     dau=3;
                     %cuoi=6;
                     %[x_tachtu,startW,endW]=tach_tu_don_DE2_GUI_iv9(x,E_sub,Fs,thresh_str,thresh_end,n_sub,dau,cuoi);
                     [x_tachtu,startW,endW]=tach_tu_don_DE2_GUI_iv9_no_tach_duoi(x(1:length_x-2*nwin),E_sub,Fs,thresh_str,n_sub,dau,t);
                     %K gioi han so bit
                     %[x_tachtu,startW,endW]=tach_tu_don_DE2_GUI_iv9_no_tach_duoi(x1,E_sub,Fs,thresh_str,n_sub,dau);
                     %fprintf('startW= %d ;  endW= %d \n',startW,endW);
                     %startW = 10;
                     %endW = length(E_sub)- 2;
                            for k=startW:endW-1
                                 x_ener1(k-startW+1)=E_sub(k)+E_sub(k+1);%tinh lai nang luong, co overlap
                            end
                            
                            x_ener=log2HW_HW(x_ener1);%tinh log2 nang luong, dung pp gan dung( kha hay)
                            %x_ener=2^9*log2(x_ener1);
                            x_ener=floor(x_ener);
                            %disp(x_ener);
                            %fid=fopen('audio.txt',w);
                            %fprintf(fid,'%
                       %fname=sprintf('%s_%s_after_cut_to_HW.txt',name,index(j+1));
                       %save(fname,'x_tachtu');
                         %  fprintf('############    2 - PRE-EMPHASIS   ############ \n');
                            %disp(x_tachtu);
                            x_pre = pre_emphasis_GUI_SW_iv1(x_tachtu,heso_a);
                            x_pre=floor(x_pre);
                            %x_pre=floor(x_pre2);
                            %disp(x_pre);
                            %K gioi han so bit
                %******************* MODULE 2: Trich dac trung ******************

                           % fprintf('############    3 - Windowing:        ############ \n');
                            x_win=window_GUI_SW_iv1(x_pre,Fs);
                            x_win=floor(x_win);
                            %disp(x_win);
                           % he so can luu y khi thay doi so bit
                           % nwin=size(x_win,2);

                % ###############  su dung fft cua Matlab   ##################            
                            %fprintf('############    4 - FFT:        ############ \n');
                            x_r=[]; % dung loai bo kich thuoc va noi dung 
                            x_i=[]; % dung loai bo kich thuoc va noi dung 
                            % cua mang luu o vong lap truoc do kieu gan 
                            % theo kieu tung phan tu gay ra
              % ######################################################  
                            %nwind=size(x_win,2);
                            %x_fft=[];
                            %for l=1:nwind
                            %    x_fft(:,l)=fft(x_win(:,l),128);
                            %end            
                            %x_fft(65:128,:)=[];
                            %x_fft=floor(x_fft);
                            %x_mag=MagnitudeHW(x_fft);
                % ######################################################             
                           [xr,xi]=fft_GUI_SW_iv1(x_win);
                           x_r=floor(xr);
                           x_i=floor(xi);
                           %fprintf('xr = \n')
                           %disp(x_r);
                % ######################################################

                %fprintf('############    5 - Magnitude:        ############ \n');
                            x_mag=MagnitudeHW_HW(x_r,x_i);
                            x_mag=floor(x_mag);              
                            %disp(x_mag);
                            
                            %fprintf('############    6 - Filterbank:        ############ \n');
                            x_FB=filterbankHW(x_mag);
                            x_FB=floor(x_FB);
                           
                            
                            %fprintf('############    7 - Log2:        ############ \n');
                            x_log2=log2HW_HW(x_FB); 
                            %x_log2=2^9*log2(x_FB); 
                           
                            
                            %fprintf('############    8 - DCT:        ############ \n');
                            x_DCT=dctHW_HW_cos_verilog(x_log2);
                           
                            x_DCT1=[];
                            x_DCT1=floor(x_DCT/2^(12));
                           
                             
                            %fprintf('############    9 - Delta:        ############ \n');
                            x_mfcc=deltaHW_DE2(x_DCT1,x_ener);
%                            fname1=sprintf('%s_%s_mfcc_value2.txt',name,index(j+1));
%                            save(fname1,'x_mfcc');                            
                            x_mfcc(13,:)=floor(x_mfcc(13,:)/2^(10));
                            x_mfcc(26,:)=floor(x_mfcc(26,:)/2^(10));

                          
                % fprintf('###########   MFCC   ############\n');         
                           data{j}=num2cell(x_mfcc);
    end
  

%******************* MODULE 3: huan luyen ******************
fprintf(' Training: \n');
HMM_auto_GUI(data,m,model_path,n_state,n_mix);
end
end
