function [a,startW,endW]=tach_tu_don_DE2_GUI_iv9_no_tach_duoi(x,E,Fs,E_str,n_sub,dau,t)

% ############## Last update: 29/9/2013  ###################
% Edited by Vo Quoc Viet 
% input: toi da 28bit
% output: toi da 64bit
% ######################### input ###############
% x: input data
% E: nang luong cua tung subframe
% Fs: tan so lay mau
% E_str: he so nhan doi voi nhieu nen dung de xac dinh diem bat dau am
%       thanh co nghia
% n_sub: so subfram dung tinh nang luong nhieu nen
% dau:
% t: thoi gian 1 khung cua so = 1 subframe - don vi la ms
% ######################### output ###############
% a: chinh la x sau khi da tach
% startW: khi nl 1 subframe >NL trung binh * he so (=E_th) thi bat dau lay tu
%           (frame do - 3 frame)
% endW:  ko tach duoi => mac dinh lay frame cuoi cung la (nf-2)
%  Chuong trinh nay dung de tach tu voi cach tinh nang luong theo subframe
%  Dung cho chuong trich dac trung co module "tach tu"


n=t*Fs/1000 ;% so sample / subframe = chieu dai 1 subframe =80
nf=size(E,2);

% #############  tinh theo cach subframe non overlap   #########

E_th=0;
for i=1:n_sub
    E_th=E_th+E(i);
end
E_th=E_th/n_sub;
%E_th: nang luong trung binh cua nhieu hay nguong nang luong de phat hien
%tieng noi hay la khoang lang

% #####################################################
kt=0;%kt= false => chua bat dau am thanh co nghia = khoang lang
for i=1:nf-1
     if ((E(i) > (E_str*E_th)))&&(kt==0)  
        startW=i-dau;% khi nl 1 subframe >NL trung binh * he so (=E_th) thi bat dau lay tu (frame do - 3 frame)
        kt=1;
     end   
end
endW=nf-2;%ko tach duoi => mac dinh lay frame cuoi cung la (nf-2)
startf=(startW-1)*n+1; % de phu hop ket qua tren DE2 => co the thay doi duoc
endf=(endW+1)*n;    % do khi khao sat va thuc hien tren DE2 thay khoang nay co kq tot

a=x(startf:endf+1); 

end
