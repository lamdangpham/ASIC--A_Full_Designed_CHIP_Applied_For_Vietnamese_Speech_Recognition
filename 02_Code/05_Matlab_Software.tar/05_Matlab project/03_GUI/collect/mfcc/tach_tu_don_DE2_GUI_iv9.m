function [a,startW,endW]=tach_tu_don_DE2_GUI_iv9(x,E,Fs,E_str,E_end,n_sub,dau,cuoi)

%  Chuong trinh nay dung de tach tu voi cach tinh nang luong theo subframe
%  Last update: 22/11/2012 by Vo Quoc Viet
%  Dung cho chuong trich dac trung co module "tach tu"

t=10 ;% t la thoi gian 1 khung cua so = 1 subframe - don vi la ms
n=t*Fs/1000 ;% so sample / subframe = chieu dai 1 subframe

nf=size(E,2);

% #############  tinh theo cach subframe non overlap   #########

E_th=0;
for i=1:n_sub
    E_th=E_th+E(i);
end
E_th=E_th/n_sub;


%   #####################################################
kt=false;
hieu=0;
%kt= false => chua bat dau am thanh co nghia = khoang lang
for i=1:nf-1
     if (E(i) > (E_str*E_th))&&(kt==false)   
        start_tam=i-dau;
        kt=true;
     end   
     if (E(i) < (E_end*E_th))&&(kt==true)
        end_tam=i+cuoi;
        kt=false;
        tinh_hieu=end_tam-start_tam;
        if tinh_hieu>hieu
            hieu=tinh_hieu;
            startW=start_tam;
            endW=end_tam;
        end
     end
end

startf=(startW-1)*n+1;
endf=(endW+1)*n;
a=x(startf:endf+1);

end
