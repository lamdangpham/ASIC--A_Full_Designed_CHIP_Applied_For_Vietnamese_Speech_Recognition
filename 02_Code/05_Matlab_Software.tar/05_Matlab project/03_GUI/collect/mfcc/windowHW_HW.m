function x=window_GUI_SW(s,fs)

% ############## Last update: 29/9/2013  ###################
% Edited by Vo Quoc Viet 
% ######################### output ###############
% output la ma tran voi 1 cot la 1 subframe da nhan voi window
% ######################### input ###############
% s: input data
% fs: tan so lay mau
% input la chuoi sample cua file am thanh tieng noi
%  ################# Subframe   ########################

nx=length(s);
nwin=(fs/1000)*10*2; % fs/1000=so sample/1ms
                    % nw : do dai frame
                    % nen moi frame 10 ms se nhan cho 10 
                    % => so sample/frame( do dai frame 10ms )
nstep=fix(nwin/2); % do dai buoc nhay(overlap=50%)
%nstep=nwin; %trong thuat toan hardware Subframe=1/2 Frame (non overlap)
nf=fix((nx-nstep)/nstep); %number of frame
f=zeros(nf,nwin)  ;          % initial array of frame f(nf,nwin)
indf= nstep*(0:(nf-1)).' ;    % vi tri bat dau cua frame  0,128,256,384,512,640,768,896,1024,1152,..3200
inds = (1:nwin);
f(:) = s(indf(:,ones(1,nwin))+inds(ones(nf,1),:));% Chua cac frame sau khi chia
nf=size(f,1); %number of frame
%doan tren dung de chia s tu 1 vecto thanh 1 ma tran voi moi hang la 1
%frame

% ##############  Hamming window fomular  ##############

%for i=1:nw
%a(i)=0.54-0.46*cos(2*pi*(i-1)/(nw-1));
%end

% ###################  REGISTER FOR  WINDOW COEFF   ##############

%w=hamming(nwin)';%tinh gia tri cos... trong cua so hamming, roi gan vao ma tran w
for l=1:nwin
w(l) = 0.54 - 0.46*cos(2*pi*(l-1)/(nwin-1));
end
%disp(w*16);
%w=fi(w*32,1,5);
%w=fix(w*16);%nhan len roi lam tron, nen nhan voi so lon hon de tang tinh chinh xac 
w=fix(w*32);
%disp(w);
%  #############################################################

for i=1:nf
y(i,:)= f(i,:) .* w(1,:); %nhan voi ham cua so
end 
%y=floor(y/16);
y=floor(y);
x=y';
end