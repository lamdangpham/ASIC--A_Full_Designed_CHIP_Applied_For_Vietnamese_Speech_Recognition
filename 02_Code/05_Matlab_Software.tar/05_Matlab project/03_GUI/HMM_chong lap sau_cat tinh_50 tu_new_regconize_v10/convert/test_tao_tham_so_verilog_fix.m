function [data_out1,data_out2]=test_tao_tham_so_verilog_fix(WORD,filename,input_path)

%input_path=input('Duong dan chua bo huan luyen tu vung: ');
%filename=input('mo hinh tu: ');
input_path1=strcat(input_path,filename,'.mat');

% ###########    LOAD gia tri tham so dau vao     ############
disp(input_path1);
S=load(input_path1);
trans=S.model.transmit;
mu= S.model.mu;  %  lay gia tri doi cua gia tri dua vao theo HW
Sigma=S.model.sigma;
mixmat=S.model.mixmat;
[d Q M] = size(mu);

for j=1:Q
    for k=1:M
        for i=1:d
            sig(i,j,k)=(Sigma(i,i,j,k)); 
        end
    end
end

% ###########  lay gia tri phu hop theo phan cung   #########
% #######################   gia tri sigma   ######################

sig=floor(-1/sig*2^8);
for j=1:Q
    for k=1:M
       % dem=0;
    for i=1:d
    %if sig(i,j,k)==-25600
    %    dem=dem+1;
    %end
    
    %end
    %if dem==26
    if sig(i,j,k)<=-25600
        sig(:,j,k)=-32;
    end    
    end
    end
end
% #######################   gia tri MU   ######################

mu=-floor(mu);

% ######################   tao lnAii   ######################

for i=1:Q
   for j=1:Q
    if trans(i,j) ==0
        trans(i,j)=2^(-1000);
    end
   end
end
lnA=floor(log(trans)*2^5);
%disp (lnA);
%mean=1;
%end_address=2*((M-1)*2^17+ mean*2^16+(WORD-1)*2^10+(Q-1)*2^6+(d-1)*2);
%data_out3=zeros(end_address,2);
%data_out4=zeros(end_address,2);
%for i=1:end_address
%    data_out3(i,1)=i;
%    data_out4(i,1)=i;
%end
% ###########################################################
%X=zeros(Q,M);
n=0;
mean=1;
    for j=1:Q
        for k=1:M
            detSig=1;
            for i=1:d       %trong HW dung d=26
                
                addr1HB=(k-1)*2^17+    mean*2^16+(WORD-1)*2^10+(j-1)*2^6+(i-1)*2;      %dia chi cua mean HB
              %  addr1LB=(k-1)*2^17+    mean*2^16+(WORD-1)*2^10+(j-1)*2^6+(i-1)*2+1;      %dia chi cua mean LB
				addr2HB=(k-1)*2^17+(mean-1)*2^16+(WORD-1)*2^10+(j-1)*2^6+(i-1)*2;  %dia chi cua variance HB
			  % addr2LB=(k-1)*2^17+(mean-1)*2^16+(WORD-1)*2^10+(j-1)*2^6+(i-1)*2+1;  %dia chi cua variance LB
             
			   n=n+1;
% ################################      High Bit    ##################################
                %disp(mu(i,j,k));
              
              %  kt_mu(n)=mu(i,j,k);
              %  kt_sig(n)=sig(i,j,k);

                data_out1(n,2)=mu(i,j,k); % luu gia tri: trung binh
                data_out1(n,1)=addr1HB;     % luu gia tri: addr1          
                %data_out1(:,2)=decsign2hex_audio(data_out1(:,2));
 %               data_out3(addr1HB,1)=mu(i,j,k);
              
                data_out2(n,2)=sig(i,j,k);% luu gia tri: phuong sai
                data_out2(n,1)=addr2HB;       % luu gia tri: addr2
                %data_out2(:,2)=decsign2hex_audio(data_out2(:,2));
                detSig=detSig*sig(i,j,k);
%				data_out4(addr2HB,1)=sig(i,j,k);
% ###############################test thu ###############
                if (j<=8)&&(k<=2)&&(WORD==1)
                    fprintf('n=%d :\n     mu (%d, %d, %d)= %d ',n,i,j,k,data_out1(n,2));
                    fprintf('     addr= %d \n',data_out1(n,1));
                    fprintf('     Sig (%d, %d, %d)= %d ',i,j,k,data_out2(n,2));
                    fprintf('     addr= %d \n',data_out2(n,1));
                    
                   % fprintf('sigma ( %d, %d, %d )= %d \n',i,j,k,Sigma(i,j,k));
                end
           
	% ################################      Low Bit      ##################################
                                  
            end

                MS=sqrt((2*pi)^d*detSig);       %d la so chieu =26
                C(j,k)=mixmat(j,k)/MS;   
                n=n+1;
				% #######################      HB      #################################
				lnC(j,k)=floor(log(C(j,k)));
                A(j,k)=(lnC(j,k)+lnA(j,j));
                data_out1(n,2)=(A(j,k)); %A
                data_out1(n,1)=addr1HB+2; 
                % dia chi cuoi cung cua tap tham so (mu)
                % se + 1 de tao ra dia chi chua tham so lnC+lnAii  
                data_out2(n,2)=0;
                data_out2(n,1)=addr2HB+2;
                % dia chi cuoi cung cua tap tham so (sigma)
                % se + 1 de tao ra dia chi chua tham so lnAij - lnAii
				% nhung vi gia tri nay chi duoc them vao cuoi qua trinh
                % so sanh cac gia tri trong khoi Reg X de tim gia tri 
                % CXmax, CXmin. nen fai doi khi lap het M bo tron moi gan
                % gia tri nay. binh thuong thi cac vung dia chi nay se dc
                % mac dinh la 0
                if (j<=8)&&(k<=2)&&(WORD==1)
                    fprintf('C( %d, %d)= %10d \n',j,k,lnC(j,k));
                    fprintf('A( %d, %d)= %10d \n',j,j,lnA(j,j));
                    fprintf('n=%d :\n     A (%d, %d)= %d ',n,j,k,data_out1(n,2));
                    fprintf('     addr= %d \n',data_out1(n,1));
                    fprintf('      %d ',data_out2(n,2));
                    fprintf('     addr= %d \n',data_out2(n,1));
                end
        end
            if j<Q
                B(j)=(lnA(j,j+1)-lnA(j,j));
                %B(j)=(lnA(j-1,j)-lnA(j-1,j-1));
                %n=n-1;
                %data_out2(n,2)=mod(B(j),256);% B
                data_out2(n,2)=B(j);
                if (j<=8)&&(k<=2)&&(WORD==1)  
                fprintf('n= %d \n A( %d, %d)= %10d \n',n,j,j,lnA(j,j));
                fprintf('A( %d, %d)= %10d \n',j,j+1,lnA(j,j+1));
                fprintf('     B(%d)= %d \n',j,data_out2(n,2));
                fprintf('     addr= %d \n',data_out2(n,1));
                end
               % n=n+1;
          %  else 
                %B(j)=(lnA(j,j+1)-lnA(j,j));
          %      B(j)=(lnA(j-1,j)-lnA(j-1,j-1));
             %   n=n-1;
          %      data_out2(n,2)=mod(B(j),256);% B
          %      if (j<=8)&&(k<=2)&&(WORD==1)    
          %      fprintf('n= %d \n A( %d, %d)= %10d \n',n,j-1,j-1,lnA(j-1,j-1));
          %      fprintf('A( %d, %d)= %10d \n',j-1,j,lnA(j-1,j));
          %      fprintf('     B (%d)= %d \n',j,data_out2(n,2));
          %      fprintf('     addr= %d \n',data_out2(n,1));
          %      end
             %   n=n+1;
          %  end
             % dia chi cuoi cung cua tap tham so (sigma)
             % se + 1 de tao ra dia chi chua tham so lnAij - lnAii 
           end
        
    
   % if WORD==1
   %     [r,c]=size(data_out2);
   %     for k=1:r
   %         fprintf('%d ; %d ; %d\n',k,data_out2(k,1),data_out2(k,2));
   %     end
   % end
   %######################
   % [r,c]=size(data_out1);
   % for i=1:r
   %     fprintf('%10d  :  fram_dataout<= \n',data_out1(i,1));
   %     fprintf('%10d  :  fram_dataout<= \n',(data_out1(i,1)+1));
   % end
   % for i=1:r
   %     fprintf('%10d  :  fram_dataout<= \n',data_out2(i,1));
   %     fprintf('%10d  :  fram_dataout<= \n',(data_out2(i,1)+1));
   % end
end
    