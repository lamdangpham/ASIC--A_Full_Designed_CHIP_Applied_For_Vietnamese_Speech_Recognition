function test_tao_tham_so_fix_DE2_GUI_v5(input_path,output_path,filename,n_state,n_mix,shift_c,shift_d,shift_num,start,finish)
%function
%[a1,b1,c1,d1,a2,b2,c2,d2,a3,b3,c3,d3,a4,b4,c4,d4,a5,b5,c5,d5,a6,b6,c6,d6,a7,b7,c7,d7,a8,b8,c8,d8,a9,b9,c9,d9,a10,b10,c10,d10]=tao_tham_so_MrThanh
%input_path=input('Duong dan chua bo huan luyen tu vung: ');
%input_path='D:\vnsr\data_sram_luanvan\data 22_6\model\8s-2m-PTN-ver4\';
%filename=input('Nhap ten file nap KIT: ');
    addr1=[];
    data1=[];
    for i=start:finish
        switch i
            case 1
                [a1,b1]=test_tao_tham_so_verilog_fix(1,'khong',input_path);
                addr1=[addr1 a1(:,1)' b1(:,1)'];
                data1=[data1 a1(:,2)' b1(:,2)'];
                %disp(data1);
            case 2
                [a2,b2]=test_tao_tham_so_verilog_fix(2,'mot',input_path);
                addr1=[addr1 a2(:,1)' b2(:,1)'];
                data1=[data1 a2(:,2)' b2(:,2)'];
            case 3
                [a3,b3]=test_tao_tham_so_verilog_fix(3,'hai',input_path);
                addr1=[addr1 a3(:,1)' b3(:,1)'];
                data1=[data1 a3(:,2)' b3(:,2)'];
            case 4
                [a4,b4]=test_tao_tham_so_verilog_fix(4,'ba',input_path);
                addr1=[addr1 a4(:,1)' b4(:,1)'];
                data1=[data1 a4(:,2)' b4(:,2)'];
            case 5
                [a5,b5]=test_tao_tham_so_verilog_fix(5,'bon',input_path);
                addr1=[addr1 a5(:,1)' b5(:,1)'];
                data1=[data1 a5(:,2)' b5(:,2)'];
            case 6
                [a6,b6]=test_tao_tham_so_verilog_fix(6,'nam',input_path);
                addr1=[addr1 a6(:,1)' b6(:,1)'];
                data1=[data1 a6(:,2)' b6(:,2)'];
            case 7
                [a7,b7]=test_tao_tham_so_verilog_fix(7,'sau',input_path);
                addr1=[addr1 a7(:,1)' b7(:,1)'];
                data1=[data1 a7(:,2)' b7(:,2)'];
            case 8
                [a8,b8]=test_tao_tham_so_verilog_fix(8,'bay',input_path);
                addr1=[addr1 a8(:,1)' b8(:,1)'];
                data1=[data1 a8(:,2)' b8(:,2)'];
            case 9
                [a9,b9]=test_tao_tham_so_verilog_fix(9,'tam',input_path);
                addr1=[addr1 a9(:,1)' b9(:,1)'];
                data1=[data1 a9(:,2)' b9(:,2)'];
            case 10
                [a10,b10]=test_tao_tham_so_verilog_fix(10,'chin',input_path);
                addr1=[addr1 a10(:,1)' b10(:,1)'];
                data1=[data1 a10(:,2)' b10(:,2)'];
            case 11
                [a11,b11]=test_tao_tham_so_verilog_fix(11,'lich',input_path);
                addr1=[addr1 a11(:,1)' b11(:,1)'];
                data1=[data1 a11(:,2)' b11(:,2)'];
            case 12
                [a12,b12]=test_tao_tham_so_verilog_fix(12,'su',input_path);
                addr1=[addr1 a12(:,1)' b12(:,1)'];
                data1=[data1 a12(:,2)' b12(:,2)'];
            case 13
                [a13,b13]=test_tao_tham_so_verilog_fix(13,'van',input_path);
                addr1=[addr1 a13(:,1)' b13(:,1)'];
                data1=[data1 a13(:,2)' b13(:,2)'];
            case 14
                [a14,b14]=test_tao_tham_so_verilog_fix(14,'hoas',input_path);
                addr1=[addr1 a14(:,1)' b14(:,1)'];
                data1=[data1 a14(:,2)' b14(:,2)'];
            case 15
                [a15,b15]=test_tao_tham_so_verilog_fix(15,'giao',input_path);
                addr1=[addr1 a15(:,1)' b15(:,1)'];
                data1=[data1 a15(:,2)' b15(:,2)'];
            case 16
                [a16,b16]=test_tao_tham_so_verilog_fix(16,'duc',input_path);
                addr1=[addr1 a16(:,1)' b16(:,1)'];
                data1=[data1 a16(:,2)' b16(:,2)'];
            case 17
                [a17,b17]=test_tao_tham_so_verilog_fix(17,'khoa',input_path);
                addr1=[addr1 a17(:,1)' b17(:,1)'];
                data1=[data1 a17(:,2)' b17(:,2)'];
            case 18
                [a18,b18]=test_tao_tham_so_verilog_fix(18,'hoc',input_path);
                addr1=[addr1 a18(:,1)' b18(:,1)'];
                data1=[data1 a18(:,2)' b18(:,2)'];
            case 19
                [a19,b19]=test_tao_tham_so_verilog_fix(19,'nong',input_path);
                addr1=[addr1 a19(:,1)' b19(:,1)'];
                data1=[data1 a19(:,2)' b19(:,2)'];
            case 20
                [a20,b20]=test_tao_tham_so_verilog_fix(20,'nghiep',input_path);
                addr1=[addr1 a20(:,1)' b20(:,1)'];
                data1=[data1 a20(:,2)' b20(:,2)'];
            case 21
                [a21,b21]=test_tao_tham_so_verilog_fix(21,'ca',input_path);
                addr1=[addr1 a21(:,1)' b21(:,1)'];
                data1=[data1 a21(:,2)' b21(:,2)'];
                %disp(data1);
            case 22
                [a22,b22]=test_tao_tham_so_verilog_fix(22,'heo',input_path);
                addr1=[addr1 a22(:,1)' b22(:,1)'];
                data1=[data1 a22(:,2)' b22(:,2)'];
            case 23
                [a23,b23]=test_tao_tham_so_verilog_fix(23,'ga',input_path);
                addr1=[addr1 a23(:,1)' b23(:,1)'];
                data1=[data1 a23(:,2)' b23(:,2)'];
            case 24
                [a24,b24]=test_tao_tham_so_verilog_fix(24,'vit',input_path);
                addr1=[addr1 a24(:,1)' b24(:,1)'];
                data1=[data1 a24(:,2)' b24(:,2)'];
            case 25
                [a25,b25]=test_tao_tham_so_verilog_fix(25,'suc',input_path);
                addr1=[addr1 a25(:,1)' b25(:,1)'];
                data1=[data1 a25(:,2)' b25(:,2)'];
            case 26
                [a26,b26]=test_tao_tham_so_verilog_fix(26,'khoe',input_path);
                addr1=[addr1 a26(:,1)' b26(:,1)'];
                data1=[data1 a26(:,2)' b26(:,2)'];
            case 27
                [a27,b27]=test_tao_tham_so_verilog_fix(27,'cay',input_path);
                addr1=[addr1 a27(:,1)' b27(:,1)'];
                data1=[data1 a27(:,2)' b27(:,2)'];
            case 28
                [a28,b28]=test_tao_tham_so_verilog_fix(28,'hoa',input_path);
                addr1=[addr1 a28(:,1)' b28(:,1)'];
                data1=[data1 a28(:,2)' b28(:,2)'];
            case 29
                [a29,b29]=test_tao_tham_so_verilog_fix(29,'bat',input_path);
                addr1=[addr1 a29(:,1)' b29(:,1)'];
                data1=[data1 a29(:,2)' b29(:,2)'];
            case 30
                [a30,b30]=test_tao_tham_so_verilog_fix(30,'tat',input_path);
                addr1=[addr1 a30(:,1)' b30(:,1)'];
                data1=[data1 a30(:,2)' b30(:,2)'];
            case 31
                [a31,b31]=test_tao_tham_so_verilog_fix(31,'mo',input_path);
                addr1=[addr1 a31(:,1)' b31(:,1)'];
                data1=[data1 a31(:,2)' b31(:,2)'];
            case 32
                [a32,b32]=test_tao_tham_so_verilog_fix(32,'dong',input_path);
                addr1=[addr1 a32(:,1)' b32(:,1)'];
                data1=[data1 a32(:,2)' b32(:,2)'];
            case 33
                [a33,b33]=test_tao_tham_so_verilog_fix(33,'den',input_path);
                addr1=[addr1 a33(:,1)' b33(:,1)'];
                data1=[data1 a33(:,2)' b33(:,2)'];
            case 34
                [a34,b34]=test_tao_tham_so_verilog_fix(34,'quat',input_path);
                addr1=[addr1 a34(:,1)' b34(:,1)'];
                data1=[data1 a34(:,2)' b34(:,2)'];
            case 35
                [a35,b35]=test_tao_tham_so_verilog_fix(35,'cua',input_path);
                addr1=[addr1 a35(:,1)' b35(:,1)'];
                data1=[data1 a35(:,2)' b35(:,2)'];
            case 36
                [a36,b36]=test_tao_tham_so_verilog_fix(36,'phong',input_path);
                addr1=[addr1 a36(:,1)' b36(:,1)'];
                data1=[data1 a36(:,2)' b36(:,2)'];
            case 37
                [a37,b37]=test_tao_tham_so_verilog_fix(37,'khach',input_path);
                addr1=[addr1 a37(:,1)' b37(:,1)'];
                data1=[data1 a37(:,2)' b37(:,2)'];
            case 38
                [a38,b38]=test_tao_tham_so_verilog_fix(38,'ngu',input_path);
                addr1=[addr1 a38(:,1)' b38(:,1)'];
                data1=[data1 a38(:,2)' b38(:,2)'];
            case 39
                [a39,b39]=test_tao_tham_so_verilog_fix(39,'bep',input_path);
                %[a39,b39]=test_tao_tham_so_verilog_fix(39,'len',input_path);
                addr1=[addr1 a39(:,1)' b39(:,1)'];
                data1=[data1 a39(:,2)' b39(:,2)'];
            case 40
                [a40,b40]=test_tao_tham_so_verilog_fix(40,'dung',input_path);
                addr1=[addr1 a40(:,1)' b40(:,1)'];
                data1=[data1 a40(:,2)' b40(:,2)'];
            case 41
                [a41,b41]=test_tao_tham_so_verilog_fix(41,'bo',input_path);
                addr1=[addr1 a41(:,1)' b41(:,1)'];
                data1=[data1 a41(:,2)' b41(:,2)'];
                %disp(data1);
            case 42
                [a42,b42]=test_tao_tham_so_verilog_fix(42,'qua',input_path);
                addr1=[addr1 a42(:,1)' b42(:,1)'];
                data1=[data1 a42(:,2)' b42(:,2)'];
            case 43
                [a43,b43]=test_tao_tham_so_verilog_fix(43,'tiep',input_path);
                %[a43,b43]=test_tao_tham_so_verilog_fix(43,'toi',input_path);
                addr1=[addr1 a43(:,1)' b43(:,1)'];
                data1=[data1 a43(:,2)' b43(:,2)'];
            case 44
                [a44,b44]=test_tao_tham_so_verilog_fix(44,'tuc',input_path);
                %[a44,b44]=test_tao_tham_so_verilog_fix(44,'lui',input_path);
                addr1=[addr1 a44(:,1)' b44(:,1)'];
                data1=[data1 a44(:,2)' b44(:,2)'];
            case 45
                [a45,b45]=test_tao_tham_so_verilog_fix(45,'toi',input_path);
                %[a45,b45]=test_tao_tham_so_verilog_fix(45,'tooi',input_path);
                addr1=[addr1 a45(:,1)' b45(:,1)'];
                data1=[data1 a45(:,2)' b45(:,2)'];
            case 46
                [a46,b46]=test_tao_tham_so_verilog_fix(46,'nghe',input_path);
                addr1=[addr1 a46(:,1)' b46(:,1)'];
                data1=[data1 a46(:,2)' b46(:,2)'];
            case 47
                [a47,b47]=test_tao_tham_so_verilog_fix(47,'muon',input_path);
                addr1=[addr1 a47(:,1)' b47(:,1)'];
                data1=[data1 a47(:,2)' b47(:,2)'];
            case 48
                [a48,b48]=test_tao_tham_so_verilog_fix(48,'tin',input_path);
                %[a48,b48]=test_tao_tham_so_verilog_fix(48,'xuong',input_path);
                addr1=[addr1 a48(:,1)' b48(:,1)'];
                data1=[data1 a48(:,2)' b48(:,2)'];
            case 49
                [a49,b49]=test_tao_tham_so_verilog_fix(49,'chao',input_path);
                addr1=[addr1 a49(:,1)' b49(:,1)'];
                data1=[data1 a49(:,2)' b49(:,2)'];
            case 50
                [a50,b50]=test_tao_tham_so_verilog_fix(50,'ban',input_path);
                addr1=[addr1 a50(:,1)' b50(:,1)'];
                data1=[data1 a50(:,2)' b50(:,2)'];
                    
        end
    end
    addr=addr1';
    data=data1';
%addr=[a1(:,1)',b1(:,1)',a2(:,1)',b2(:,1)',a3(:,1)',b3(:,1)',a4(:,1)',b4(:,1)',a5(:,1)',b5(:,1)',a6(:,1)',b6(:,1)',a7(:,1)',b7(:,1)',a8(:,1)',b8(:,1)',a9(:,1)',b9(:,1)',a10(:,1)',b10(:,1)',a11(:,1)',b11(:,1)',a12(:,1)',b12(:,1)',a13(:,1)',b13(:,1)',a14(:,1)',b14(:,1)',a15(:,1)',b15(:,1)',a16(:,1)',b16(:,1)']';
%data=[a1(:,2)',b1(:,2)',a2(:,2)',b2(:,2)',a3(:,2)',b3(:,2)',a4(:,2)',b4(:,2)',a5(:,2)',b5(:,2)',a6(:,2)',b6(:,2)',a7(:,2)',b7(:,2)',a8(:,2)',b8(:,2)',a9(:,2)',b9(:,2)',a10(:,2)',b10(:,2)',a11(:,2)',b11(:,2)',a12(:,2)',b12(:,2)',a13(:,2)',b13(:,2)',a14(:,2)',b14(:,2)',a15(:,2)',b15(:,2)',a16(:,2)',b16(:,2)']';

%disp(data);
%data=[c1',d1',c2',d2',c3',d3',c4',d4',c5',d5',c6',d6',c7',d7',c8',d8',c9',d9',c10',d10']';
%--
max_addr=max(addr);
disp(max_addr);
%disp(data(1:60,1));
[r,c]=size(addr);
%fprintf('data (%d) = %d \n',54,data(54));
disp(addr(r));
%disp(data);
data_out=zeros(max_addr/2+6,1);
   % for i=1: floor(max_addr/2)
   %     data_out(i)= 0;
   % end
        for j=1:r   
            data_out(addr(j)/2+1)=data(j);
            %if addr(j)==131122
            %    fprintf('data (%d) = %d \n',j,data(j));
            %    disp(data(j-16:j+5));
            %end
          %  fprintf('%10d  :  %10d \n',addr(j),data(j));              
        end
     
[r1,c]=size(data_out);
fprintf('kich thuoc :');disp(r1); 
fprintf('Gia tri data[%d] = %d \n',r,data_out(r));
fprintf('Gia tri data_out[%d] = %d \n',r1,data_out(r1));
fprintf('dia chi data[%d] = %d \n',r,addr(r));
%--    
 %data_hex=decsign2hex_audio(data_out);
    %disp(data_hex);
    
%--    
%for k=40:63
%disp(data_out(k));
%end
   y=int16(data_out);
   x=swapbytes(y);
   shift_c_hex=dec2hex(shift_c);
   shift_d_hex=dec2hex(shift_d);
   
   x(30)=hex2dec(strcat('0',shift_d_hex,'0',shift_c_hex));
   n_mix_hex=dec2hex(n_mix);
   n_state_hex=dec2hex(n_state);
        x(31)=hex2dec(strcat('0',n_state_hex,'0',n_mix_hex));%1793;%n_mix;
%   word_num_hex=dec2hex(word_num);
   word_num_hex=dec2hex(finish-start);
   shift_num_hex=dec2hex(shift_num);
   if shift_num<16
       shift_num_hex=strcat('0',shift_num_hex);
   end
   if finish-start<16
       word_num_hex=strcat('0',word_num_hex);
   end
   x32=strcat(shift_num_hex,word_num_hex);
        x(32)=hex2dec(x32);%3850;%word_num;
     
      %disp(x(30));
      %disp(x(31));
      %disp(x(32));
    disp(strcat(output_path,filename));
   fid=fopen(strcat(output_path,filename),'w');
   fwrite(fid,x,'short');
   fclose(fid);
  
%--    
%Thuong add
fname=sprintf('%s.txt',filename);
fid2=fopen(strcat(output_path,fname),'w');
fid1=fopen(strcat(output_path,filename));
x1 =fread(fid1,inf,'schar');
x2 =  cellstr(dec2hex((x1<0)*256+x1));
for i=1:(length(x2)/2)
  x2_bis(i)=strcat(x2(2*i-1),x2(2*i));
end
fprintf(fid2,'%s\n',x2_bis{:});
fclose(fid2); 
fclose(fid1);
fprintf('COMPLETED...\n');
fclose('all');
end

