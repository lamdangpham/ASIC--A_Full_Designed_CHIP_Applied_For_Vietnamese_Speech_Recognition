function x=windowHW(s,fs)

%input la chuoi sample cua file am thanh tieng noi
%output la ma tran voi 1 cot la 1 subframe da nhan voi window

%  ################# Subframe   ########################

nx=length(s);
nwin=(fs/1000)*10; % fs/1000=so sample/1ms
                    % nw : do dai frame
                    % nen moi frame 10 ms se nhan cho 10 
                    % => so sample/frame( do dai frame 10ms )
%nstep=fix(nwin/2); % do dai buoc nhay(overlap=50%)
nstep=nwin; %trong thuat toan hardware Subframe=1/2 Frame (non overlap)
nf=fix((nx-nwin+nstep)/nstep); %number of frame
f=zeros(nf,nwin);            % initial array of frame f(nf,nwin)
indf= nstep*(0:(nf-1)).';     % vi tri bat dau cua frame  0,128,256,384,512,640,768,896,1024,1152,..3200
inds = (1:nwin);
f(:) = s(indf(:,ones(1,nwin))+inds(ones(nf,1),:));% Chua cac frame sau khi chia

%disp(f);

nf=size(f,1); %number of frame

%##############  Hamming window fomular  ##############

%for i=1:nw
%a(i)=0.54-0.46*cos(2*pi*(i-1)/(nw-1));
%end

% ######################################################

w=hamming(nwin)';
%disp(w);
for i=1:nf
y(i,:)= f(i,:) .* w(1,:); %nhan voi ham cua so
end 
x=y';
end