function y=MagnitudeHW(x)

% input: la ma tran da FFT voi moi cot la he so cua 1 frame
% output:la ma tran cua FFT da lay bien do voi moi cot tuog ung 1
% Frame

%maxreal=max(abs(real(x(:,:))),abs(imag(x(:,:))));
%minimag=min(abs(real(x(:,:))),abs(imag(x(:,:))));
%y(:,:)=maxreal+minimag/4;

[r,c]=size(x);

for i=1:c
for j=1:r
maxreal=max(abs(real(x(j,i))),abs(imag(x(j,i))));
minimag=min(abs(real(x(j,i))),abs(imag(x(j,i))));
if maxreal<(5/4*minimag) 
    a=15/16;
    b=15/32;
elseif ((5/4*minimag)<=maxreal)&&(maxreal<(9/4*minimag))
    a=7/8;
    b=1/2;
    elseif ((9/4*minimag)<=maxreal)&&(maxreal<(8*minimag))
        a=31/32;
        b=1/4;        
        elseif ((8*minimag)<=maxreal)
            a=1;
            b=0;
end
y(j,i)=(a*maxreal+minimag*b);
end
end

end