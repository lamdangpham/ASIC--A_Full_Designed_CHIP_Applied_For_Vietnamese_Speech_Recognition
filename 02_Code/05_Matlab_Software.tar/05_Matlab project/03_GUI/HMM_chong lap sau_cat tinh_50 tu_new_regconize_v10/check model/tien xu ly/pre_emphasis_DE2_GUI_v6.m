function y=pre_emphasis_DE2_GUI_v6(s,a)

% input: la mang 1 chieu (1xN) cua file AUDIO cua Speech 
% output: la mang 1 chieu (1xN) cua speech da duoc Pre-emp
% Last update 13/9/2012 by Vo Quoc Viet
% ###########################################################

n=length(s);
y(1:n-1)=s(2:n)-(a*s(1:n-1));

%y(1:n-1)=s(2:n)-7/8*s(1:n-1);

% ################  solution 2  ##############
% a= 31/32;
% x = filter([1, -a], 1, s);

end
