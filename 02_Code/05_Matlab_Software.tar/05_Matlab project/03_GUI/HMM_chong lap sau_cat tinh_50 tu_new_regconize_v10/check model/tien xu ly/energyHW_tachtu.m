function [y,nsf]=energyHW_tachtu(s,fs)

%input la chuoi sample cua file am thanh tieng noi
%output la ma tran (1*N) la cac gia tri nang luong cua moi subframe

%  ################# Subframe   ########################

nx=length(s);
nwin=(fs/1000)*10; % fs/1000=so sample/1ms
                    % nw : do dai frame
                    % nen moi frame 10 ms se nhan cho 10 
                    % => so sample/frame( do dai frame 10ms )
%nstep=fix(nwin/2); % do dai buoc nhay(overlap=50%)
nstep=nwin; %trong thuat toan hardware Subframe=1/2 Frame (non overlap)
nf=fix((nx-nwin+nstep)/nstep); %number of frame
f=zeros(nf,nwin);            % initial array of frame f(nf,nwin)
indf= nstep*(0:(nf-1)).';     % vi tri bat dau cua frame  0,128,256,384,512,640,768,896,1024,1152,..3200
inds = (1:nwin);
f(:) = s(indf(:,ones(1,nwin))+inds(ones(nf,1),:));% Chua cac frame sau khi chia

nsf=size(f,1); %number of subframe

% ###################   E= Sum(S(n,i)^2) +  Sum(S(n+1,i)^2) ###########

for i=1:nsf
    sum_Sn(i)=sum(f(i,:).^2);
end
y=sum_Sn;
end