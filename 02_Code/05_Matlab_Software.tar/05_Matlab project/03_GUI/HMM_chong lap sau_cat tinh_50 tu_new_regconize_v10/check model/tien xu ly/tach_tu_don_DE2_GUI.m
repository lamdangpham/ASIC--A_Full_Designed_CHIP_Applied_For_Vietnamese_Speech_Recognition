function [a,startW1,endW1]=tach_tu_don_DE2_GUI(x,E,Fs,E_str,E_end,n_sub,m)

%  Chuong trinh nay dung de tach tu voi cach tinh nang luong theo subframe
%  Last update: 15/11/2012
%  Dung cho chuong trich dac trung co module "tach tu"

t=10 ;% t la thoi gian 1 khung cua so = 1 subframe - don vi la ms
n=t*Fs/1000 ;% so sample / subframe = chieu dai 1 subframe
nx=length(x); %disp(nx);
nf=size(E,2);

% #############  tinh theo cach subframe non overlap   #########

E_th=0;
for i=1:n_sub
    E_th=E_th+E(i);
end
E_th=E_th/n_sub;
fprintf('tinh nang luong: %5.7f ',E_th);
%disp(E);
%figure(m);
%plot(E);
%   #####################################################
kt=false;
dem=0;
%kt= false => chua bat dau am thanh co nghia = khoang lang
for i=1:nf-1
     if (E(i) > (E_str*E_th))&&(kt==false)
        dem=dem+1;
        startW(dem)=i-5;
        kt=true;
     end   
     if (E(i) < (E_end*E_th))&&(kt==true)
        endW(dem)=i+5;
        kt=false;
        hieu(dem)=endW(dem)-startW(dem);
     end
end

[hieu_max,pos]=max(hieu);
disp(pos);
startW1=startW(pos);
endW1=endW(pos);
disp(startW1);
disp(endW1);
startf=(startW1-1)*n+1;
endf=(endW1+1)*n;
if (endf+1) >nx
    endf=fix(nx/n)*n-1;
    endW1=(endf+1)/n-1;
end
a=x(startf:endf+1);

end
