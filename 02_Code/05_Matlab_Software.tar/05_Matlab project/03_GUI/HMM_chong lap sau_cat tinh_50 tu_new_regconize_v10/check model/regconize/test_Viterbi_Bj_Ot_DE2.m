function y=test_Viterbi_Bj_Ot_DE2(A,data1, mu, sigma, mixmat1,model_number)

% input: la cac ma tran cua 1 model cua 1 word trong bo tu huan luyen 
%        B(j,t)la ma tran chua xs cua cac quan sat. Moi quan sat 
%        ung voi N trang thai cua mo hinh nhan dang cua tu tuong ung.
%        Trong do moi cot la xs cua obs(t)ung voi trang thai 1,2...N
% output: la xs lon nhat cua chuoi observation tuong ung voi model 
%         cua word can kiem tra.
%  ###################################################
%  ##########   Frame 1 - State 1   ##################
%  ###################################################
[d Q M] = size(mu);
[d T] = size(data1);
%mu=floor(-mu);
mu1=-floor(mu);
%if ((k>=41) && (k<=43))
if model_number==47
%model_number
  %display(mu1);
  %display(data1);
end
%Sigma=floor(-2*sig);
sig1=floor(-1/sigma*2^8);
dkD=35;
dkT=0;
for j=1:Q
    for k=1:M
        %dem=0;
    for i=1:d
   % if sig1(i,j,k)<=-25600
   %     dem=dem+1;
   % end
    
   % end
   % if dem==26
    if sig1(i,j,k)<=-25600
        sig1(:,j,k)=-32;
    end        
    end
    end
end

%Q=size(A,1);
%T=size(B,2);
Reg(1:Q)=zeros(1,Q);

%lnB=B;
%lnA=log(A);
trans=A;
for i=1:Q
   for j=1:Q
    if trans(i,j) ==0
        trans(i,j)=2^(-1000);
    end
   end
end
lnA=floor(log(trans)*2^5);
%  ###################################################
%  ###########  Frame 2->T : State 1->Q  #############
%  ###########      Score Register       #############
%  ###################################################

j=1;
t=1;% tinh cho t=2
lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number);% them
Reg(1)=Reg(1)+lnB(j,t); %B11+A11 ; Reg(1)=0;
hs_a2=lnA(j,j+1)-lnA(j,j);
Reg(2)=Reg(1)+hs_a2;%
%fprintf('t= %d ',1);disp(round(Reg));
%fprintf('hs_a2 = %10d \n',hs_a2);
%fprintf('t= %d',t);disp(round(Reg));
% if model_number==50
%  display(Reg');
%end  
%  ###################################################

t=2;% tinh cho t=3
j=1;
lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number);% them
%Reg(1)=Reg(1)+lnA(1,1)+lnB(j,t);
%Reg(2)=Reg(1)+lnA(1,2)-lnA(1,1);
Reg(1)=Reg(1)+lnB(j,t);
hs_a2=lnA(j,j+1)-lnA(j,j);
Temp=Reg(1)+hs_a2;
%if model_number==50
%  display(Reg');
%end  
%  ###################################################
j=2;
lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number);
Reg(2)=Reg(2)+lnB(j,t);
hs_a2=lnA(j,j+1)-lnA(j,j);
Reg(3)=Reg(2)+hs_a2;
if Temp>Reg(2);
    Reg(2)=Temp;
end  
%fprintf('t= %d',2);disp(round(Reg));
%fprintf('A( %d, %d)= %10d \n',1,1,lnA(1,1));
%fprintf('A( %d, %d)= %10d \n',1,2,lnA(1,2));
%fprintf('hs_a2 = %10d \n',hs_a2);
%fprintf('t= %d',t);disp(round(Reg));

%Reg(1)=Reg(1)+lnB(j,t);
%hs_a2=lnA(1,2)-lnA(1,1);
%Reg(2)=Reg(1)+hs_a2;

%  ###################################################
% t=3 -> T

for t=3:T-1
    j=1;
    if ((model_number==50) && (t==3))
      %display(data1);
    end  
    lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number);% them
    
    %Reg(1)=Reg(1)+lnA(1,1)+lnB(j,t);
    Reg(1)=Reg(1)+lnB(j,t);
    hs_a2=lnA(j,j+1)-lnA(j,j);
    Temp=Reg(1)+hs_a2;
    if t<Q
        n=t;
    else n=Q ;
    end
%  ###################################################
    for j=2:n-1
        
        lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number); % them 
        %hs_a2=lnA(j-1,j)-lnA(j-1,j-1);
        Reg(j)=Reg(j)+lnB(j,t);
        Reg_out=Reg(j);
        
        if Temp > Reg(j)
            Reg(j)=Temp;
        end
        hs_a2=lnA(j,j+1)-lnA(j,j);
        Temp=Reg_out+hs_a2;
       
        if (j<=8)&&(t<dkT)&&(dkD<t)
            fprintf('A( %d, %d)= %10d \n',j-1,j-1,lnA(j-1,j-1));
            fprintf('A( %d, %d)= %10d \n',j-1,j,lnA(j-1,j));
            fprintf('hs_a2 = %10d \n',hs_a2);
        end
       % Temp = Reg(j-1)+hs_a2;
        %Reg(j) = Reg(j)+ lnA(j,j)+lnB(j,t);
       % Reg(j) = Reg(j)+lnB(j,t);
        
    end
    if t<Q 
        j=j+1;
        lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number);
        Reg(j)=Reg(j)+lnB(j,t);
        hs_a2=lnA(j,j+1)-lnA(j,j);
        Reg(j+1)= Reg(j)+ hs_a2; %j+1=n
        if Temp > Reg(j)
            Reg(j)=Temp;
        end
    else
        j=j+1;
        lnB(j,t)=Bj_Ot_DE2(data1, mu1, sig1, mixmat1,j,t,M,lnA(j,j),model_number);
        Reg(j)=Reg(j)+lnB(j,t);
        if Temp > Reg(j)
            Reg(j)=Temp;
        end
    end
    if (t<dkT)&&(dkD<t)
         fprintf('t= %d',t);disp(round(Reg));
    end
if model_number==50
  %display(Reg');
end    
end
%display('###############################################')
%display(Reg);
%display('###############################################')
y=max(Reg);
end

function B = Bj_Ot_DE2(data, mu, sigma, mixmat,j,t,M,A_jj,model_number)

dkD=35;
dkT=0;
% ##############  tao Ck va Xk theo thuat toan HW ##############

% mu(:,:,:)luu trong bo nho la cac gia tri am nen dung phep+
%for t=1:T
   d=26;
    X=zeros(M);
    %for j=1:Q
    CXmax=-2^21;
    CXmin=CXmax;
        for k=1:M
            detSig=1;
            for i=1:d       %trong HW dung d=26
                Ot_mu(i,j,k)=data(i,t)+mu(i,j,k);        % ### ADDER
                if (t==1)&&(model_number==50)
                  %display(data(:,t));
                  %display(Ot_mu);
                end
                Mul(i,j,k)=floor(floor((Ot_mu(i,j,k)*Ot_mu(i,j,k))/32)*sigma(i,j,k));% ### Multiplier
               % if Mul(i,j,k)<(-2^15)
               %     Mul(i,j,k)=floor(Mul(i,j,k)/(ceil(Mul(i,j,k)/(-2^15))));
               % end
                X(k)=X(k)+Mul(i,j,k);                % ### Core Adder
                detSig=detSig*sigma(i,j,k);         % ### Multiplier  
                if (abs(Ot_mu(i,j,k))>2^15)||(abs(Mul(i,j,k))>2^20)
                    fprintf('%d  -  %d   = %10d = Ot_mu(%d, %d,%d)\n',data(i,t),mu(i,j,k),Ot_mu(i,j,k),i,j,k);
                    fprintf('sigma= %d ; Mul(%d, %d,%d)= %10.0f \n',sigma(i,j,k),i,j,Mul(i,j,k));
                    fprintf('da tran tai t = %d\n ',t);
                    break;
                end
                if (j<=8)&&(k<=2)&&(t<dkT)&&(dkD<t)
                    fprintf('%d  + ( %d )  = %10d = Ot_mu(%d, %d,%d)= \n',data(i,t),mu(i,j,k),Ot_mu(i,j,k),i,j,k);
                    fprintf('sigma= %d ;\n Mul(%d, %d, %d)= %10d \n',sigma(i,j,k),i,j,k,Mul(i,j,k));
                    fprintf('X(%d, %d)= %10.0f \n',j,k,X(k));
                    disp(' ');
                end
               % disp(' ');
                %   thay Sigma(i,i,j,k)=Sigma(i,j,k);  
            end
            
           % MS=sqrt((2*pi)^26*detSig);     %trong HW dung d=26
                MS=sqrt((2*pi)^d*detSig);       %d la so chieu
                C(j,k)=mixmat(j,k)/MS;
                lnC(j,k)=floor(log(C(j,k)));
                hs_a1(k)=lnC(j,k)+A_jj;
                if (j<=8)&&(k<=2)&&(t<dkT)&&(dkD<t)
                   fprintf('C( %d, %d)= %10d \n',j,k,lnC(j,k));
                   fprintf('A( %d, %d)= %10d \n',j,j,A_jj);
                   fprintf('hs_a1= %10d \n',hs_a1(k));
                   disp(' ');
                end
                IN=hs_a1(k)+X(k);
                if  IN > CXmax 
                CXmin=CXmax;
                CXmax=IN   ; 
                elseif IN>CXmin
                CXmin=IN ;
                end
          
      
       end
        
    
% ######   X Register: store ln(Cmax)+ Xmax; ln(Cmin)+ Xmin  ######
 
       %Cmax=C(j,1);
       %Cmin=C(j,1);
       %Xmax=X(1);
       %Xmin=X(1);
       %CXmax=floor(log(Cmax)+Xmax); % #### Core Adder
       %CXmin=floor(log(Cmin)+Xmin); % #### Core Adder
 
 % ###########################################
       %for k=1:M 
       %    hs_a1(k)=floor(log(C(j,k)))+A_jj;
           
       %end
 % ###########################################      
           
      
       %CXmax=floor(hs_a1(1)+X(1)); 
       %CXmax=-2^21;
       %CXmin=CXmax;
       %for k=1:M 
            %In=(floor(log(C(j,k)))+A_jj+X(k));
            %hs_a1=floor(log(C(j,k)))+A_jj;
            %fprintf ('%6d ;',hs_a1);
       %     IN=hs_a1(k)+X(k);
       %     if  IN > CXmax 
              %  Cmax=C(j,k);
              %  Xmax=X(j,k);
       %         CXmin=CXmax;
       %         CXmax=IN   ; %log(Cmax)+Xmax; %  #### Core Adder
       %     elseif IN>CXmin
       %         CXmin=IN ;
                
       %     end
            
      
      % end
       %for k=2:M 
            %IN=(floor(log(C(j,k)))+A_jj+X(k));
       %     hs_a1=floor(log(C(j,k)))+A_jj;
       %     IN=hs_a1+X(k);
       %     if  (IN < CXmin)&& (IN<CXmax) 
               % Cmin=C(j,k);
               % Xmin=X(j,k);
       %         CXmin=IN ;%log(Cmin)+Xmin; %  #### Core Adder
       %     end
      % end
      
%  ##################   Subtractor   #################
    
% Hieu=(log(Cmin)+Xmin)-(log(Cmax)+Xmax);
   
        Hieu=CXmin-CXmax;
            
%  ################## look up table  #################

         sub=Hieu + log(M/2);   %  #### Core Adder

% luythua: la index trong thuat toan cua HW dung de tra bang LUT
% trong HW:(luythua <=> index):luythua= 0->ln4 khi M=8
% index la chi so cua cac o nho tu 0->160 

         LUT=log(1 + exp(sub)); 
         
% trong HW: LUT = 0->ln5 = 1.61
% 
% ################### tinh toan cho Bj(Ot)  ##########

         B=CXmax + LUT;        %  #### Core Adder
         if (j<=8)&&(t<dkT)&&(dkD<t)
            
            fprintf('j=%d \n min=%d  -  max=%d  ; Sub = %d \n',j,CXmin,CXmax, Hieu);
            fprintf('Bj_Ot = %9d \n',B);
            disp(' ');
         end
    %end
%end
end