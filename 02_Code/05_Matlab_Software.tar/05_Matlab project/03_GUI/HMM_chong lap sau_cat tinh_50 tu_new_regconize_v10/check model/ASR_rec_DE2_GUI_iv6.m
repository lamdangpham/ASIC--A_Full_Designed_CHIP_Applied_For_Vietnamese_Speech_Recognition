function sx=ASR_rec_DE2_GUI_iv6(input_path,model_path,start,finish,n_file,thresh_str,thresh_end,n_sub,heso_a,input_type)


% ##############  Last update12/9/2012   ###################
% Edited by Vo Quoc Viet
% Chuong trinh nay dung de nhan dang

%******************* MODULE 0: du lieu vao ******************


count1=zeros(finish-start,finish-start);
count2=zeros(finish-start,finish-start);
counta=0;
countb=0;
%xuat=strcat('C:\Users\ba\Downloads\audio-de-cat\he so mfcc\heso_mfcc');
%disp(xuat);
%file1=fopen(xuat,'w');
for tu=start:finish
  pos=tu;
  switch tu
    case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
    case 5 
      word='bon';    
    case 6 
      word='nam';    
    case 7 
      word='sau';    
    case 8 
      word='bay';    
    case 9
      word='tam';    
    case 10 
      word='chin';    
    case 11 
      word='lich';    
    case 12 
      word='su';    
    case 13 
      word='van';    
    case 14 
      word='hoa';    
    case 15 
      word='giao';    
    case 16 
      word='duc';    
    case 17 
      word='khoa';    
    case 18 
      word='hoc';    
    case 19 
      word='nong';    
    case 20 
      word='nghiep';    
    case 21 
      word='ca';    
    case 22 
      word='heo';    
    case 23 
      word='ga';    
    case 24 
      word='vit';    
    case 25 
      word='suc';    
    case 26 
      word='khoe';    
    case 27 
      word='cay';    
    case 28 
      word='hoa';  
      %word='di';    
    case 29 
      word='bat';    
    case 30 
      word='tat';    
    case 31 
      word='mo';    
    case 32 
      word='dong';    
    case 33 
      word='den';    
    case 34 
      word='quat';    
    case 35 
      word='cua';    
    case 36 
      word='phong';    
    case 37 
      word='khach';    
    case 38 
      word='ngu';    
    case 39 
      word='bep';  
      %word='len';    
    case 40 
      word='dung';    
    case 41 
      word='bo';    
    case 42 
      word='qua';    
    case 43 
      word='tiep';  
      %word='toi';    
    case 44 
      word='tuc';  
      %word='lui';    
    case 45 
      word='toi';  
      %word='tooi';    
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      word='tin';
      %word='xuong';    
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end
  for j=1:n_file
   if (strcmp(input_type,'wav'))
      if tu<10
        path=strcat(input_path,num2str(0),num2str(tu),'_',word,'\file - nhan dang/',num2str(j),'.wav');
      else
        path=strcat(input_path,num2str(tu),'_',word,'\file - nhan dang/',num2str(j),'.wav');
      end
      disp(path);
      [x1 Fs] =wavread(path);
      x1=x1*2^15;
    else
      if tu<10
        path=strcat(input_path,num2str(0),num2str(tu),'_',word,'\file - nhan dang/',num2str(j));
      else
        path=strcat(input_path,num2str(tu),'_',word,'\file - nhan dang/',num2str(j));
      end
   end
      disp(path);
      Fs=8000;                   
      file=fopen(path);
      x1=fread(file,inf,'short');
      fclose(file);


        %soundsc(x1,Fs,16);
        %figure(19);
        %plot(s);

        %*******************    MODULE 1: Tien xu ly   ******************

                    %fprintf('############    1 - Energy & Detect word    ############ \n');
                    nx=size(x1,1);
                    if mod(nx,80)>0
                        nx=fix(nx/80)*80;
                        x1(1:nx,1)=x1(1:nx,1);
                    end 
                    [E_sub,nsf]= energyHW_tachtu(x1,Fs);
                    x_ener1=[];x_ener=[];

                    %[x_tachtu,startW,endW]=tach_tu_don_DE2_GUI(x1,x_ener1,Fs,thresh_str,thresh_end,n_sub,tu);
                    [x_tachtu,startW,finishW]=cat_tinh(x1,Fs); 
                    x_ener=0;
                    x_tachtu;
                            fprintf('startW= %d ;  endW= %d \n',startW,finishW);
                            for k=startW:finishW-1
                                 x_ener1(k-startW+1)=E_sub(k)+E_sub(k+1);%tinh lai nang luong, co overlap
                            end
                            x_ener=2^9*log2(x_ener1);
                            x_ener=floor(x_ener);
                         %  fprintf('############    2 - PRE-EMPHASIS   ############ \n');
                           % figure(tu+10);
                           % plot(x_tachtu);
                             x_pre = pre_emphasis_DE2_GUI_v6(x_tachtu,heso_a);
                            x_pre=floor(x_pre);

                %******************* MODULE 2: Trich dac trung ******************

                           % fprintf('############    3 - Windowing:        ############ \n');
                            x_win=windowHW(x_pre,Fs);
                            x_win=floor(x_win);

                            nwin=size(x_win,2);

                % ###############  su dung fft cua Matlab   ##################            
                            %fprintf('############    4 - FFT:        ############ \n');
                            x_fft=[]; % dung loai bo kich thuoc va noi dung 
                            % cua mang luu o vong lap truoc do kieu gan 
                            % theo kieu tung phan tu gay ra
                            for l=1:nwin
                                x_fft(:,l)=fft(x_win(:,l),128);
                            end            
                            x_fft(65:128,:)=[];
                            x_fft=floor(x_fft);

                % ######################################################

                            %fprintf('############    5 - Magnitude:        ############ \n');
                            x_mag=MagnitudeHW(x_fft);
                            x_mag=floor(x_mag);              

                            %fprintf('############    6 - Filterbank:        ############ \n');
                            x_FB=filterbankHW(x_mag);
                            x_FB=floor(x_FB);

                            %fprintf('############    7 - Log2:        ############ \n');
                            x_log2=2^9*log2(x_FB); 

                            %fprintf('############    8 - DCT:        ############ \n');
                            x_DCT=dctHW_HW_cos_verilog(x_log2);
                            x_DCT1=floor(x_DCT/2^(12));
                            %fprintf('############    9 - Delta:        ############ \n');
                            x_mfcc=deltaHW_DE2(x_DCT1,x_ener);
                            x_mfcc(13,:)=floor(x_mfcc(13,:)/2^(10));
                            x_mfcc(26,:)=floor(x_mfcc(26,:)/2^(10));
                            %x_mfcc=floor(x_mfcc/2^(12));
                            %[r_mfcc,c_mfcc]=size(x_mfcc);
                            %ten=strcat('Tu " ',name,index,' " :');
                           % disp(xuat);
                           % file=fopen(xuat,'w');
                          % fprintf(file1,ten);
                          % fprintf(file1,'\n');
                          %  for cot=1 : c_mfcc
                          %      for hang=1:r_mfcc
                          %          fprintf(file1,'%5d', x_mfcc(hang,cot));
                          %      end
                          %      fprintf(file1,'\n');
                          %  end
                          % fprintf(file1, '\n'); 
                           % fclose(file);                      
                            %disp(x_mfcc'); 
           % fprintf('###########   MFCC   ############\n');         
             
%******************* MODULE 3: nhan dang ******************

for k=1:2
   
switch k
    case 1 
      filename='khong';
    case 2 
      filename='mot';    
    case 3 
      filename='hai';    
    case 4 
      filename='ba';    
    case 5 
      filename='bon';    
    case 6 
      filename='nam';    
    case 7 
      filename='sau';    
    case 8 
      filename='bay';    
    case 9
      filename='tam';    
    case 10 
      filename='chin';    
    case 11 
      filename='lich';    
    case 12 
      filename='su';    
    case 13 
      filename='van';    
    case 14 
      filename='hoa';    
    case 15 
      filename='giao';    
    case 16 
      filename='duc';    
    case 17 
      filename='khoa';    
    case 18 
      filename='hoc';    
    case 19 
      filename='nong';    
    case 20 
      filename='nghiep';    
    case 21 
      filename='ca';    
    case 22 
      filename='heo';    
    case 23 
      filename='ga';    
    case 24 
      filename='vit';    
    case 25 
      filename='suc';    
    case 26 
      filename='khoe';    
    case 27 
      filename='cay';    
    case 28 
      filename='hoa';  
      %filename='di';    
    case 29 
      filename='bat';    
    case 30 
      filename='tat';    
    case 31 
      filename='mo';    
    case 32 
      filename='dong';    
    case 33 
      filename='den';    
    case 34 
      filename='quat';    
    case 35 
      filename='cua';    
    case 36 
      filename='phong';    
    case 37 
      filename='khach';    
    case 38 
      filename='ngu';    
    case 39 
      filename='bep';  
      %filename='len';    
    case 40 
      filename='dung';    
    case 41 
      filename='bo';    
    case 42 
      filename='qua';    
    case 43 
      filename='tiep';  
      %filename='toi';    
    case 44 
      filename='tuc';  
      %filename='lui';    
    case 45 
      filename='toi';  
      %filename='tooi';    
    case 46 
      filename='nghe';    
    case 47 
      filename='muon';    
    case 48
      filename='tin';
      %filename='xuong';    
    case 49 
      filename='chao';    
    case 50 
      filename='ban';  
   end
input_path1=strcat(model_path,filename,'.mat');
%disp(input_path1);
S=load(input_path1);
%prior=S.word.prior;

%transmit=S.word.transmit;
%mu=S.word.mu;
%Sigma=S.word.sigma;
%mixmat=S.word.mixmat;

transmit=S.model.transmit;
mu=S.model.mu;
Sigma=S.model.sigma;
mixmat=S.model.mixmat;


[r,c,d1,d2]=size(Sigma);
for i=1:r
    for j=1:d1
        for m=1:d2
            sigma(i,j,m)=Sigma(i,i,j,m);
        end
    end
end

data=x_mfcc;

%B2=Bj_Ot_prob_DE2(data,mu,sigma,mixmat);

%Pmax1(k)=viterbiHW_HW(transmit,B2);
Pmax1(k)=test_Viterbi_Bj_Ot_DE2(transmit,data, mu, sigma, mixmat);
k;
if k==2
    Pmax1
end
%Pmax2(k)=viterbiHW_HW_verilog_16b(transmit,B2);
end

[max1,pos_1]=max(Pmax1);
%disp(input_name(pos_1));
%disp(Pmax1);
%disp(pos_1);

%[max2,pos_2]=max(Pmax2);

pos1(i)=pos_1;
%pos2(i)=pos_2;

%count1(pos,pos_1)=count1(pos,pos_1)+1;
%count2(pos,pos_2)=count2(pos,pos_2)+1;
if pos==pos_1
    counta=counta+1;
end
%if pos==pos_2
%    countb=countb+1;
%end
 

end
end

 %fclose(file1);                      
    %disp(counta);
%disp(countb);
%start
%finish
%n_file
counta
sx=counta/((-start+finish+1)*n_file)*100;
disp(count1);

%disp(count2);
end