function y=enerHW_DE2_iv9(s,fs)

% edit 23/11/2012 by Vo Quoc Viet
nwin=(fs/1000)*10;%=80
%nx=fix(length(s)/nwin);
nx=length(s);
nstep=nwin; %trong thuat toan hardware Subframe=1/2 Frame (non overlap)
nf=fix((nx-nwin+nstep)/nstep); %number of subframe
%disp(max(max(abs(s))));
for i=2:nx
    s_bp(i-1)=s(i)^2; % bo diem dau tien theo nhu code cua HW
end

for i=1:nf
    ener(i)=0;
    for j=1:nwin
        ener(i)=ener(i)+s_bp((i-1)*nwin+j);%non overlap
        %fprintf(' ener (%d) = %d \n',i,ener(i));
    end
    
end

y=ener;
end