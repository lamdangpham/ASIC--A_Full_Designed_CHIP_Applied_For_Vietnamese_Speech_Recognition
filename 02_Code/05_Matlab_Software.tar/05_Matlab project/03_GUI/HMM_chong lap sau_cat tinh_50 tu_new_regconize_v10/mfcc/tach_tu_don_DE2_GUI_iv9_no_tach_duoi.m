function [a,startW,endW]=tach_tu_don_DE2_GUI_iv9_no_tach_duoi(x,E,Fs,E_str,n_sub,dau)

%  Chuong trinh nay dung de tach tu voi cach tinh nang luong theo subframe
%  Last update: 22/11/2012 by Vo Quoc Viet
%  Dung cho chuong trich dac trung co module "tach tu"

t=10 ;% t la thoi gian 1 khung cua so = 1 subframe - don vi la ms
n=t*Fs/1000 ;% so sample / subframe = chieu dai 1 subframe =80

nf=size(E,2);

% #############  tinh theo cach subframe non overlap   #########

E_th=0;
for i=1:n_sub
    E_th=E_th+E(i);
end
E_th=E_th/n_sub;
%E_th: nang luong trung binh cua 1 tu

%   #####################################################
kt=0;%kt= false => chua bat dau am thanh co nghia = khoang lang
for i=1:nf-1
     if ((E(i) > (E_str*E_th)))&&(kt==0)  
        startW=i-dau;% khi nl 1 subframe >NL trung binh * he so (=E_th) thi bat dau lay tu (frame do - 3 frame)
        kt=1;
     end   
end
endW=nf-2;%ko tach duoi => mac dinh lay frame cuoi cung la (nf-2)
startf=(startW-1)*n+1;
endf=(endW+1)*n;
%xd diem bat dau lay va diem ket thuc lay (mo rong 1 frame ve fia 2 dau)
a=x(startf:endf+1); %a chinh la x sau khi da tach

end
