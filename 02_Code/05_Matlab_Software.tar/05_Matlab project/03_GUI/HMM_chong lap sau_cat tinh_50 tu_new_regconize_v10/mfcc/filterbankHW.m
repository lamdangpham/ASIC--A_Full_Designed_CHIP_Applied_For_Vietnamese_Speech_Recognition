function y=filterbankHW(x)

%input la ma tran voi 1 cot la hs cua 1 frame sau fft 
%output la matran voi 1 cot la hs cua 1 frame sau nhanvoi filterbank

[r,c]=size(x);

nfilter=23; %so bo loc trong de tai phan cung chon

filtertab=zeros(r,nfilter);

% tao bo loc cho filter bank - bo loc hinh chu nhat

filtertab(1:2,1)=1;
filtertab(1:3,2)=1;
filtertab(2:5,3)=1;
filtertab(3:6,4)=1;
filtertab(5:7,5)=1;
filtertab(6:9,6)=1;
filtertab(7:10,7)=1;
filtertab(9:12,8)=1;
filtertab(10:14,9)=1;
filtertab(12:16,10)=1;
filtertab(14:18,11)=1;
filtertab(16:20,12)=1;
filtertab(18:23,13)=1;
filtertab(20:26,14)=1;
filtertab(23:29,15)=1;
filtertab(26:32,16)=1;
filtertab(29:35,17)=1;
filtertab(32:39,18)=1;
filtertab(35:43,19)=1;
filtertab(39:48,20)=1;
filtertab(43:53,21)=1;
filtertab(48:58,22)=1;
filtertab(53:64,23)=1;
%tao ma tran 3 duong cheo giua

% ############ nhan bo loc tao SF'nk ###################

for n=1:c
    for k=1:23
        x_mel(k,n)=sum(x(:,n).*filtertab(:,k));
    end
end
%fprintf('Filterbank \n');
%disp(x_mel);
% ############  overlap: Snk=SF'nk + SF'(n+1)k #########

for n=1:c-1             % c la so subframe
Snk(:,n)=x_mel(:,n)+x_mel(:,n+1);
end
%Snk(:,c)=2*x_mel(:,c);  % c-1 la so frame
y=Snk;
end
