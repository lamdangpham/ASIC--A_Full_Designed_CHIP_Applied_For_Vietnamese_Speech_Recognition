function delta=deltaHW_DE2(x,E)

%disp(size(x));
n_E=size(E,2);
%disp(n_E);
x_energy=[x(:,1:n_E-1);E(2:n_E)]; % cach dat nay co hoi khac voi code deltaHW_HW
[r,c]=size(x_energy);
x_energy(14:r,:)=[];

%x_e(:,3:c+2)=x_energy(:,1:c);
%x_e(:,1)=x_energy(:,1);
%x_e(:,2)=x_energy(:,1);
%x_e(:,c+3)=x_energy(:,c);
%x_e(:,c+4)=x_energy(:,c);

for i=3:c-2
    d(:,i-2)=(2*(x_energy(:,i+2)-x_energy(:,i-2))+(x_energy(:,i+1)-x_energy(:,i-1)));
end
x_e=x_energy(:,3:c-2);
%disp(size(x_e));
%disp(size(d));
delta=[x_e;d];%ghep them he so nang luong va cepstral
end