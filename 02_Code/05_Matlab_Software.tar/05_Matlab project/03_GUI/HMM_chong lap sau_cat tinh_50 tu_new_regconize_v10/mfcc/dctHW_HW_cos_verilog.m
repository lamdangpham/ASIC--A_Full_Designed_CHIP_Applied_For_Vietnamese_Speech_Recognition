function y=dctHW_HW_cos_verilog(x)

[N,c]=size(x);

%  #############    REGISTER DCT coefficient     ###############

%for p=1:N
%   for k=1:N
%       Cp(k,p)=(cos((k-0.5)*(p-1)*pi/N)*64);
%   end
%end
for p=1:12
   for k=1:N
       TG=(cos((k-0.5)*p*pi/N)*64);
       if TG>0
           Cp(k,p)=floor(TG);%lam trong xuong
       else
           Cp(k,p)=ceil(TG);%lam tron len
       end
   end
end
%disp(Cp);
%   ###########################################################

for i=1:c
   %for p=1:N
    for p=1:12 % vi chi lay 12 he so dau, thay vi lay het N he so

    y(p,i)=sum(x(:,i).*Cp(:,p)); %  theo phan cung thi nhan 64 k can chia xuog
    end
end
%fprintf(' he so DCT: \n');
%disp(Cp);
end