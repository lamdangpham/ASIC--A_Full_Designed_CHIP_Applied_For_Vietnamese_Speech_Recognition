function y=MagnitudeHW_HW(xr,xi)

% input: la ma tran da FFT voi moi cot la he so cua 1 frame
% output:la ma tran cua FFT da lay bien do voi moi cot tuog ung 1
% Frame

%maxreal=max(abs(real(x(:,:))),abs(imag(x(:,:))));
%minimag=min(abs(real(x(:,:))),abs(imag(x(:,:))));
    maxreal=max(abs(xr(:,:)),abs(xi(:,:)));
    minimag=min(abs(xr(:,:)),abs(xi(:,:)));
    y(:,:)=fix(maxreal+minimag/4);%?????
%[r,c]=size(xr);

%for i=1:c
%for j=1:r
%    maxreal=max(xr(i,j),ir(i,j));
%    minimag=min(xr(i,j),ir(i,j));
%    y(j,i)=fix(maxreal+minimag/4);
%end
%end

end