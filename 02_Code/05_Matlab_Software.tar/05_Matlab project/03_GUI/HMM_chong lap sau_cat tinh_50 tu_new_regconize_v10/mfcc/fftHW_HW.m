function [Real,Imag]=fftHW_HW(x)

% input: la ma tran da windowing voi moi cot la he so cua 1 frame
% output:la ma tran cua FFT voi moi cot tuog ung la i frame
% voi gia tri ngo ra la cac so nguyen
[N,t]=size(x);
if N<128
    x(N+1:128,:)=0;% them cho du 128 gia tri.
    N=128;
end
heso=64;
%  #################   REGISTER FFT COEFF   ###################
n=N/2;
d=[ 0    -3    -6    -9   -12   -16   -19   -22   -24   -27   -30   -33   -36   -38   -41   -43   -45   -47   -49   -51 -53   -55   -56   -58   -59   -60   -61   -62   -63   -63   -64   -64   -64   -64   -64   -63   -63   -62   -61   -60 -59   -58   -56   -55   -53   -51   -49   -47   -45   -43   -41   -38   -36   -33   -30   -27   -24   -22   -19   -16 -12    -9    -6    -3
    ];
c=[ 64    64    64    63    63    62    61    60    59    58    56    55    53    51    49    47    45    43    41    38 36    33    30    27    24    22    19    16    12     9     6     3     0    -3    -6    -9   -12   -16   -19   -22 -24   -27   -30   -33   -36   -38   -41   -43   -45   -47   -49   -51   -53   -55   -56   -58   -59   -60   -61   -62 -63   -63   -64   -64
    ];
%for j=1:(n)
%    mu=-(2*1i*pi/N);
%    W(j)=exp(mu*(j-1));
    %c(j)=fi(real(W(j))*64,1,8); 
    %d(j)=fi(imag(W(j))*64,1,8);
%    c(j)=floor(real(W(j))*heso); 
%    d(j)=floor(imag(W(j))*heso);
    %if c(j)==128
    %    c(j)=c(j)-1;
    %end
    %if d(j)==128
    %    d(j)=d(j)-1;
    %end
%   ###########################################################    
%   ## doi sang he nhi phan co fan fraction danh cho HW   ##
%   ## c(j) = bin (c(j)); convert negative & positive dec => bin
%   ## d(j) = bin (d(j)); dec: la so thap phan co dau
%   ###########################################################

%end

%disp(d);

%   ####################   cach 2   ##########################

% for i=0:63
% c(i+1)=  cos(2*pi*i/128); (register for real)
% d(i+1)= -sin(2*pi*i/128); (register for image)
% end 

%   ###########################################################

Stage=log2(N);

for i=1:t
    
%  #####   dao bit cac chi so de tao gia tri vao tinh FFT   #####

nbit=size(dec2bin(N-1),2);
for j=1:N
    index=dec2bin((j-1),nbit);
    reverse=index(nbit:-1:1);
    %quy luat lay dao bit theo thu tu nguoc de tim vi tri cho butterfly
    jrev=bin2dec(reverse)+1;
    %A(j)=x(jrev,i);
    Y(j)=x(jrev,i);
    a(j)=real(Y(j));
    b(j)=0;
end
%disp(a);

%   ############   Butterfly : tinh gia tri FFT  ###########

for s=1:Stage                 %stage
   % fprintf( 'Stage= %d \n',s);
    group=2^(Stage-s);
    for j=1:group          %buoc nhay hay so luong hs trong nhom
        startgr=(j-1)*2^s+1;
        endgr=(j-1/2)*2^s;    %(j-1)*2^s+2^(s-1)
        q=1;
        step=N/(2^s);
        for k=startgr:endgr
           % fprintf(' W[%d]',q);
            stepk=2^(s-1);
           % B(k)=A(k)+W(q)*A(k+stepk);
           % B(k+stepk)=A(k)-W(q)*A(k+stepk);
         
           % A(k)=B(k);
           % A(k+stepk)=B(k+stepk);
                      
            rtemp= floor((a(k+stepk)*c(q)-b(k+stepk)*d(q))/heso);
            itemp= floor((b(k+stepk)*c(q)+a(k+stepk)*d(q))/heso);
            %rtemp= floor((a(k+stepk)*c(q)-b(k+stepk)*d(q)));
            %itemp= floor((b(k+stepk)*c(q)+a(k+stepk)*d(q)));
            atemp=a(k);
            btemp=b(k);
            a(k)= a(k)+rtemp;
            b(k)= b(k)+itemp;
         
            a(k+stepk)= atemp-rtemp;
            b(k+stepk)= btemp-itemp;
            q=q+step;
        end
      %  disp(' ');
    end
   % fprintf('Stage: %d \n',s);
   % disp(a(1:5));disp(a(65:70));
   % disp(b(1:5));disp(b(65:70));
end
Real(:,i)=(a)';
Imag(:,i)=(b)';
%Real(:,i)=fix(A/1)';
%Imag(:,i)=fix(B/1)';
end
Real(n+1:N,:)=[];
Imag(n+1:N,:)=[];

end