function y=log2HW_HW(x)

% input: la ma tran da filter bank voi moi cot la he so cua 1 frame
% output:la ma tran cac gia tri da lay Log2 
% voi moi cot tuog ung la 1 frame
% chi su dung cho cac gia tri nho hon 2^10



[N,c]=size(x);

for j=1:c
    for i=1:N
        n=dec2bin(x(i,j));
      %  fprintf('n= \n');disp(n);
        
        nbit=length(n);
      %  fprintf('nbit=%d \n',nbit);
        
        k=2^9*(nbit-1);
      %  fprintf('k=%d \n',k);
        if nbit<10
            n(nbit+1:10)='0';
        end
        temp=n(2:10);
      %  fprintf('temp= ');disp(temp);
        
        %temp(nbit:nshift)='0';
      %  disp(size(temp));
      %  fprintf('temp da dich = ');disp(temp);
        
        m=bin2dec(temp);
      %  fprintf('m=%d \n',m);
        y(i,j)=(k+m);
        %y(i,j)=((k+m)/(2^9));
        %y(i,j)=(k+m)/(2^9); neu muon tinh chinh xac theo so thap 
    end
end

end