function [mu, Sigma, weights] = mixgauss_init_cell_ASR(M, data, cov_type, method)
% MIXGAUSS_INIT Initial parameter estimates for a mixture of Gaussians
% function [mu, Sigma, weights] = mixgauss_init(M, data, cov_type. method)
%
% INPUTS:
% data(:,t) is the t'th example
% M = num. mixture components
% cov_type = 'full', 'diag' or 'spherical'
% method = 'rnd' (choose centers randomly from data) or 'kmeans' (needs netlab)
%
% OUTPUTS:
% mu(:,k) 
% Sigma(:,:,k) 
% weights(k)

if nargin < 4, method = 'kmeans'; end

n_seq = size(data,2);
data1=[];
data_sample=cell2mat(data{1});
disp(size(data_sample));
for i=1:n_seq
    data1=[data1 data{i}];
end
data1=cell2mat(data1);
d =size(data{1},1);
fprintf('data max = %d \n',floor(max(max(max(data1)))));
fprintf('data min = %d \n',floor(min(min(min(data1)))));
%fprintf('truoc gmm %d    %d   \n',size(data_sample));
%data = reshape(data, d, T); % in case it is data(:, t, sequence_num)
 
switch method
 case 'rnd', 
  C = cov(data');
  Sigma = repmat(diag(diag(C))*0.5, [1 1 M]);
  % Initialize each mean to a random data point
  indices = randperm(T);
  mu = data(:,indices(1:M));
  weights = normalise(ones(M,1));
 case 'kmeans',
  mix = gmm_ASR(d, M, cov_type,data_sample');
  
  fprintf('kich thuoc mau dau tien:\n');
  disp(size(data_sample));
 
  % fprintf('gmm max = %d \n',floor(max(max(max(mix.centres)))));
 % fprintf('gmm min = %d \n',floor(min(min(min(mix.centres)))));
 % disp(mix);
  options = foptions;
  max_iter = 10;                   %#######  thu tang so vong lap
  options(1) = -1; % be quiet!
  options(14) = max_iter;
  %fprintf('data truoc hoan vi \n'); 
  %disp(data1);
  %fprintf('data sau hoan vi \n'); 

  mix = gmminit_ASR(mix, data1', options);
 % disp(mix);
  mu = reshape(mix.centres', [d M]);
  weights = mix.priors(:);
  %fprintf('gmminit max = %d \n',floor(max(max(max(mix.centres)))));
  %fprintf('gmmonit min = %d \n',floor(min(min(min(mix.centres)))));
  for m=1:M
    switch cov_type
     case 'diag',
      Sigma(:,:,m) = diag(mix.covars(m,:));
     case 'full',
      Sigma(:,:,m) = mix.covars(:,:,m);
     case 'spherical',
      Sigma(:,:,m) = mix.covars(m) * eye(d);
    end
  end
end

