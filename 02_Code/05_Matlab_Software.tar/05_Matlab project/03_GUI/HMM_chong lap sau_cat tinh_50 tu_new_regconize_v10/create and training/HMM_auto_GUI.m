function HMM_auto_GUI(data,lib,model_path,n_state,n_mix)

%Last update: 25/7/2012
 
  M = n_mix;          %Number of mixtures 
  Q = n_state;          %Number of states 

cov_type = 'diag';

[O,T]=size(data{1});

eps=10^(-20);
prior0(1:Q,1)=eps;
prior0(1,1)=1-(Q-1)*eps;
%transmat0 = mk_stochastic(rand(Q,Q));
transmat0(1:Q,1:Q)=eps;
for i=1:(Q-1)
    transmat0(i,i)=0.8;
    transmat0(i,i+1)=1-transmat0(i,i)-(Q-2)*eps;
end
transmat0(Q,Q)=1-(Q-1)*eps;
%transmat0(1,1)=1-(Q-1)*eps;
fprintf(' khoi tao: \n');


%############     khoi tao EM dung K-mean  ###########
fprintf('khoi tao\n');
if 0
  Sigma0 = repmat(eye(O), [1 1 Q M]);
  % Initialize each mean to a random data point
  indices = randperm(T*nex);
  mu0 = reshape(data(:,indices(1:(Q*M))), [O Q M]);
  mixmat0 = mk_stochastic(rand(Q,M));
else
  [mu0, Sigma0] = mixgauss_init_cell_ASR(Q*M, data, cov_type);
  mu0 = reshape(mu0, [O Q M]);
  Sigma0 = reshape(Sigma0, [O O Q M]);
  mixmat0 = mk_stochastic(rand(Q,M));
  %khoi tao bang doan tren
end

  %##################     tinh toan   A,pi,u, sigma,   ##############

 
fprintf('\n tinh toan \n');

[LL, prior1, transmat1, mu1, Sigma1, mixmat1] = ...
 mhmm_em_cell(data, prior0, transmat0, mu0, Sigma0, mixmat0, 'max_iter', 5);
 
loglik = mhmm_logprob2(data, prior1, transmat1, mu1, Sigma1, mixmat1);
%figure(100);
disp(LL);
%plot(LL);

%##################     save cac ket qua vao thu muc   ##############

word.prior=prior1;
word.transmit=transmat1;
word.mu=mu1;
word.sigma=Sigma1;
word.mixmat=mixmat1;


fprintf('lib = %d \n',lib);
    switch lib
    case 1 
      filename='khong';
    case 2 
      filename='mot';    
    case 3 
      filename='hai';    
    case 4 
      filename='ba';    
    case 5 
      filename='bon';    
    case 6 
      filename='nam';    
    case 7 
      filename='sau';    
    case 8 
      filename='bay';    
    case 9
      filename='tam';    
    case 10 
      filename='chin';    
    case 11 
      filename='lich';    
    case 12 
      filename='su';    
    case 13 
      filename='van';    
    case 14 
      filename='hoa';    
    case 15 
      filename='giao';    
    case 16 
      filename='duc';    
    case 17 
      filename='khoa';    
    case 18 
      filename='hoc';    
    case 19 
      filename='nong';    
    case 20 
      filename='nghiep';    
    case 21 
      filename='ca';    
    case 22 
      filename='heo';    
    case 23 
      filename='ga';    
    case 24 
      filename='vit';    
    case 25 
      filename='suc';    
    case 26 
      filename='khoe';    
    case 27 
      filename='cay';    
    case 28 
      filename='hoa';  
      %filename='di';    
    case 29 
      filename='bat';    
    case 30 
      filename='tat';    
    case 31 
      filename='mo';    
    case 32 
      filename='dong';    
    case 33 
      filename='den';    
    case 34 
      filename='quat';    
    case 35 
      filename='cua';    
    case 36 
      filename='phong';    
    case 37 
      filename='khach';    
    case 38 
      filename='ngu';    
    case 39 
      filename='bep';  
      %filename='len';    
    case 40 
      filename='dung';    
    case 41 
      filename='bo';    
    case 42 
      filename='qua';    
    case 43 
      filename='tiep';  
      %filename='toi';    
    case 44 
      filename='tuc';  
      %filename='lui';    
    case 45 
      filename='toi';  
      %filename='tooi';    
    case 46 
      filename='nghe';    
    case 47 
      filename='muon';    
    case 48
      filename='tin';
      %filename='xuong';    
    case 49 
      filename='chao';    
    case 50 
      filename='ban';  
   end

disp (filename);
output_path=strcat(model_path,filename);
save (output_path, 'word');
disp(output_path);

end