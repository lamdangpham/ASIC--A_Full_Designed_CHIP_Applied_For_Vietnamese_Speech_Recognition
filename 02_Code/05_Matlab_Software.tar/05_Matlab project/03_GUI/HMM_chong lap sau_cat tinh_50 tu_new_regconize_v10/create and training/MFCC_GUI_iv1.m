function MFCC_GUI_iv1( input_path,output_path,start,finish,n_file,heso_a,input_type )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
for m=start:finish
  switch m
   case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
    case 5 
      word='bon';    
    case 6 
      word='nam';    
    case 7 
      word='sau';    
    case 8 
      word='bay';    
    case 9
      word='tam';    
    case 10 
      word='chin';    
    case 11 
      word='lich';    
    case 12 
      word='su';    
    case 13 
      word='van';    
    case 14 
      word='hoas';   
      %word='hoa'; 
    case 15 
      word='giao';    
    case 16 
      word='duc';    
    case 17 
      word='khoa';    
    case 18 
      word='hoc';    
    case 19 
      word='nong';    
    case 20 
      word='nghiep';    
    case 21 
      word='ca';    
    case 22 
      word='heo';    
    case 23 
      word='ga';    
    case 24 
      word='vit';    
    case 25 
      word='suc';    
    case 26 
      word='khoe';    
    case 27 
      word='cay';    
    case 28 
      word='hoa';  
      %word='di';    
    case 29 
      word='bat';    
    case 30 
      word='tat';    
    case 31 
      word='mo';    
    case 32 
      word='dong';    
    case 33 
      word='den';    
    case 34 
      word='quat';    
    case 35 
      word='cua';    
    case 36 
      word='phong';    
    case 37 
      word='khach';    
    case 38 
      word='ngu';    
    case 39 
      word='bep';  
      %word='len';    
    case 40 
      word='dung';    
    case 41 
      word='bo';    
    case 42 
      word='qua';    
    case 43 
      word='tiep';  
      %word='toi';    
    case 44 
      word='tuc';  
      %word='lui';    
    case 45 
      word='toi';  
      %word='tooi';    
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      word='tin';
      %word='xuong';    
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end
  m
  for j=1:n_file
    if (strcmp(input_type,'wav'))
      if m<10
        path=strcat(input_path,'\',num2str(0),num2str(m),'_',word,'\file - huan luyen/',num2str(j),'.wav');
      else
        path=strcat(input_path,'\',num2str(m),'_',word,'\file - huan luyen/',num2str(j),'.wav');
      end
      disp(path);
      [x1 Fs] =wavread(path);
      x1=x1*2^15;
    else
      if m<10
        path=strcat(input_path,'\',num2str(0),num2str(m),'_',word,'\file - huan luyen/',num2str(j));
      else
        path=strcat(input_path,'\',num2str(m),'_',word,'\file - huan luyen/',num2str(j));
      end
      disp(path);
      Fs=8000;                   
      file=fopen(path);
      x1=fread(file,inf,'short');
      fclose(file);
    end
    Fs = 8000;
    t=10;%t la thoi gian 1 khung cua so = 1 subframe - don vi la ms
    nwin=Fs/1000*t; % chuong trinh dung Fs=8000Hz nen nwin=80
    %soundsc(x1,Fs,16);
    % figure(19);
    % plot(x1);
%%  *******************    MODULE 1: Tien xu ly   ******************
%{
%%  Energy & Detect word
    nx=length(x1); 
    x=0;
                     
    %hieu chinh 
    if mod(nx,nwin)>0
      nx=fix(nx/nwin)*nwin;
      x(1:nx+1,1)=x1(1:nx+1,1);
    else
       x(1:nx,1)=x1(1:nx,1);
       x(nx+1,1)=x1(nx,1);
    end
    length_x=length(x);
    E_sub= enerHW_DE2_iv9(x(1:length_x-2*nwin),Fs); %trong code nay da bo qua tinh binh phuong cho gia tri dau cua data
    %ko tinh 2 frame cuoi
    
    x_ener1=[];
    
    %cat am thanh
    [x_tachtu,startW,finishW]=cat_tinh(x(1:length_x-2*nwin),Fs);
    startW;
    finishW;
    E_sub;
    %fprintf('startW= %d ;  endW= %d \n',startW,endW);
    for k=startW:finishW-1
      x_ener1(k-startW+1)=E_sub(k)+E_sub(k+1);%tinh lai nang luong, co overlap
    end
%}
    nx=length(x1); 
    x1(nx+1,1)=x1(nx,1);
    E_sub= enerHW_DE2_iv9(x1,Fs);
    x_tachtu=x1;
    x_ener1=[];
    for k=1:length(x_tachtu)/nwin-1
      x_ener1(k)=E_sub(k)+E_sub(k+1);%tinh lai nang luong, co overlap
    end
    x_ener=log2HW_HW(x_ener1);%tinh log2 nang luong, dung pp gan dung
    %x_ener=2^9*log2(x_ener1);
    x_ener=floor(x_ener);
    
%%  PRE-EMPHASIS
    %{
    fname=sprintf('%s_%s_after_cut_to_HW.txt',word,num2str(j));
    length_xtt = length(x_tachtu);
    x_tachtu_HW = x_tachtu;
    x_tachtu_HW(length_xtt+1:length_xtt+240) = 0; %chi can them 3 frame =0 de phan cung biet dung
    x_tachtu_HW = cellstr(dec2hex((x_tachtu_HW<0)*65536+x_tachtu_HW));
    %save(fname,'x_tachtu_HW');
    path1=strcat('D:\03_Project\05_Matlab project\mfcc_rec_to_Mr Thuong','\',fname);
    fid=fopen(path1,'w');
    %for i = 1 : length_xtt
    fprintf(fid,'%s\n',x_tachtu_HW{:});       
    %x_tachtu
    %}
    x_pre = pre_emphasis_DE2_GUI_iv9(x_tachtu,heso_a);
                            
    x_pre=floor(x_pre);
                            
%%  ******************* MODULE 2: Trich dac trung ******************
%%  Windowing
    x_win=windowHW_HW(x_pre,Fs);
    x_win=floor(x_win);

%%  FFT
    x_r=[];
    x_i=[];
    [xr,xi]=fftHW_HW(x_win);
    x_r=floor(xr);
    x_i=floor(xi);
    
%%  Magnitude
    x_mag=MagnitudeHW_HW(x_r,x_i);
    x_mag=floor(x_mag);              
                            
%%  Filterbank
    x_FB=filterbankHW(x_mag);
    x_FB=floor(x_FB);
                             
%%  Log2
    x_log2=log2HW_HW(x_FB); 
    %x_log2=2^9*log2(x_FB);   
    
%%  DCT
    x_DCT=dctHW_HW_cos_verilog(x_log2);
    x_DCT1=[];
    x_DCT1=floor(x_DCT/2^(12));
                          
%%  Delta
    x_mfcc=deltaHW_DE2(x_DCT1,x_ener);
    x_mfcc(13,:)=floor(x_mfcc(13,:)/2^(10));
    x_mfcc(26,:)=floor(x_mfcc(26,:)/2^(10));
    %data{j}=num2cell(x_mfcc);
    data{j}=x_mfcc;  
    
    if j==n_file
      if m<10
        path_out=[output_path,'\',num2str(0),num2str(m),'_',word];  
        mkdir(path_out);
      else
        path_out=[output_path,'\',num2str(m),'_',word];
        mkdir(path_out);
      end
      save([path_out,'/mfcc.mat'],'data');
    end
  end
 
  
end
end

