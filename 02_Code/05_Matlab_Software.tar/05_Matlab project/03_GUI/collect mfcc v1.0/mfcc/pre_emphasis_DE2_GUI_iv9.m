function y=pre_emphasis_DE2_GUI_iv9(s,a)

% input: la mang 1 chieu (1xN) cua file AUDIO cua Speech 
% output: la mang 1 chieu (1xN) cua speech da duoc Pre-emp
% Last update 13/9/2012 by Vo Quoc Viet
% ###########################################################

n=length(s);
for i=1:n-1
    if abs(s(i))>32
        %y(i)=s(i+1)-s(i)+floor(s(i)/32);
        y(i)=s(i+1)-floor(s(i)*a);
    else 
        %y(i)=s(i+1)-s(i)+fix(s(i)/32);
        y(i)=s(i+1)-fix(s(i)*a);
    end
end
%floor: lam tron xuong
%fix: lay phan nguyen
%tai sao lai phai chia ra nhu vay?
% ################  solution 2  ##############
% a= 31/32;
% x = filter([1, -a], 1, s);

end
