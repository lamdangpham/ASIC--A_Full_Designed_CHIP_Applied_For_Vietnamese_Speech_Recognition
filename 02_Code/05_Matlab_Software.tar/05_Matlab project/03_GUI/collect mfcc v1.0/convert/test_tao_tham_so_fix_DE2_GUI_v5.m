function test_tao_tham_so_fix_DE2_GUI_v5(input_path,output_path,filename,n_state,n_mix,shift_c,shift_d,shift_num,word_num)
%function
%[a1,b1,c1,d1,a2,b2,c2,d2,a3,b3,c3,d3,a4,b4,c4,d4,a5,b5,c5,d5,a6,b6,c6,d6,a7,b7,c7,d7,a8,b8,c8,d8,a9,b9,c9,d9,a10,b10,c10,d10]=tao_tham_so_MrThanh
%input_path=input('Duong dan chua bo huan luyen tu vung: ');
%input_path='D:\vnsr\data_sram_luanvan\data 22_6\model\8s-2m-PTN-ver4\';
%filename=input('Nhap ten file nap KIT: ');
    addr1=[];
    data1=[];
    for i=1:word_num
        switch i
            case 1
                [a1,b1]=test_tao_tham_so_verilog_fix(1,'khong',input_path);
                addr1=[addr1 a1(:,1)' b1(:,1)'];
                data1=[data1 a1(:,2)' b1(:,2)'];
                %disp(data1);
            case 2
                [a2,b2]=test_tao_tham_so_verilog_fix(2,'mot',input_path);
                addr1=[addr1 a2(:,1)' b2(:,1)'];
                data1=[data1 a2(:,2)' b2(:,2)'];
            case 3
                [a3,b3]=test_tao_tham_so_verilog_fix(3,'hai',input_path);
                addr1=[addr1 a3(:,1)' b3(:,1)'];
                data1=[data1 a3(:,2)' b3(:,2)'];
            case 4
                [a4,b4]=test_tao_tham_so_verilog_fix(4,'ba',input_path);
                addr1=[addr1 a4(:,1)' b4(:,1)'];
                data1=[data1 a4(:,2)' b4(:,2)'];
            case 5
                [a5,b5]=test_tao_tham_so_verilog_fix(5,'bon',input_path);
                addr1=[addr1 a5(:,1)' b5(:,1)'];
                data1=[data1 a5(:,2)' b5(:,2)'];
            case 6
                [a6,b6]=test_tao_tham_so_verilog_fix(6,'nam',input_path);
                addr1=[addr1 a6(:,1)' b6(:,1)'];
                data1=[data1 a6(:,2)' b6(:,2)'];
            case 7
                [a7,b7]=test_tao_tham_so_verilog_fix(7,'sau',input_path);
                addr1=[addr1 a7(:,1)' b7(:,1)'];
                data1=[data1 a7(:,2)' b7(:,2)'];
            case 8
                [a8,b8]=test_tao_tham_so_verilog_fix(8,'bay',input_path);
                addr1=[addr1 a8(:,1)' b8(:,1)'];
                data1=[data1 a8(:,2)' b8(:,2)'];
            case 9
                [a9,b9]=test_tao_tham_so_verilog_fix(9,'tam',input_path);
                addr1=[addr1 a9(:,1)' b9(:,1)'];
                data1=[data1 a9(:,2)' b9(:,2)'];
            case 10
                [a10,b10]=test_tao_tham_so_verilog_fix(10,'chin',input_path);
                addr1=[addr1 a10(:,1)' b10(:,1)'];
                data1=[data1 a10(:,2)' b10(:,2)'];
            case 11
                [a11,b11]=test_tao_tham_so_verilog_fix(11,'goi',input_path);
                addr1=[addr1 a11(:,1)' b11(:,1)'];
                data1=[data1 a11(:,2)' b11(:,2)'];
            case 12
                [a12,b12]=test_tao_tham_so_verilog_fix(12,'towi',input_path);
                addr1=[addr1 a12(:,1)' b12(:,1)'];
                data1=[data1 a12(:,2)' b12(:,2)'];
            case 13
                [a13,b13]=test_tao_tham_so_verilog_fix(13,'lui',input_path);
                addr1=[addr1 a13(:,1)' b13(:,1)'];
                data1=[data1 a13(:,2)' b13(:,2)'];
            case 14
                [a14,b14]=test_tao_tham_so_verilog_fix(14,'duwng',input_path);
                addr1=[addr1 a14(:,1)' b14(:,1)'];
                data1=[data1 a14(:,2)' b14(:,2)'];
            case 15
                [a15,b15]=test_tao_tham_so_verilog_fix(15,'chay',input_path);
                addr1=[addr1 a15(:,1)' b15(:,1)'];
                data1=[data1 a15(:,2)' b15(:,2)'];
            case 16
                [a16,b16]=test_tao_tham_so_verilog_fix(16,'dduwng',input_path);
                addr1=[addr1 a16(:,1)' b16(:,1)'];
                data1=[data1 a16(:,2)' b16(:,2)'];
            case 17
                [a17,b17]=test_tao_tham_so_verilog_fix(17,'trai',input_path);
                addr1=[addr1 a17(:,1)' b17(:,1)'];
                data1=[data1 a17(:,2)' b17(:,2)'];
            case 18
                [a18,b18]=test_tao_tham_so_verilog_fix(18,'phai',input_path);
                addr1=[addr1 a18(:,1)' b18(:,1)'];
                data1=[data1 a18(:,2)' b18(:,2)'];
            case 19
                [a19,b19]=test_tao_tham_so_verilog_fix(19,'duoi',input_path);
                addr1=[addr1 a19(:,1)' b19(:,1)'];
                data1=[data1 a19(:,2)' b19(:,2)'];
            case 20
                [a20,b20]=test_tao_tham_so_verilog_fix(20,'tren',input_path);
                addr1=[addr1 a20(:,1)' b20(:,1)'];
                data1=[data1 a20(:,2)' b20(:,2)'];
        end
    end
    addr=addr1';
    data=data1';
%addr=[a1(:,1)',b1(:,1)',a2(:,1)',b2(:,1)',a3(:,1)',b3(:,1)',a4(:,1)',b4(:,1)',a5(:,1)',b5(:,1)',a6(:,1)',b6(:,1)',a7(:,1)',b7(:,1)',a8(:,1)',b8(:,1)',a9(:,1)',b9(:,1)',a10(:,1)',b10(:,1)',a11(:,1)',b11(:,1)',a12(:,1)',b12(:,1)',a13(:,1)',b13(:,1)',a14(:,1)',b14(:,1)',a15(:,1)',b15(:,1)',a16(:,1)',b16(:,1)']';
%data=[a1(:,2)',b1(:,2)',a2(:,2)',b2(:,2)',a3(:,2)',b3(:,2)',a4(:,2)',b4(:,2)',a5(:,2)',b5(:,2)',a6(:,2)',b6(:,2)',a7(:,2)',b7(:,2)',a8(:,2)',b8(:,2)',a9(:,2)',b9(:,2)',a10(:,2)',b10(:,2)',a11(:,2)',b11(:,2)',a12(:,2)',b12(:,2)',a13(:,2)',b13(:,2)',a14(:,2)',b14(:,2)',a15(:,2)',b15(:,2)',a16(:,2)',b16(:,2)']';

%disp(data);
%data=[c1',d1',c2',d2',c3',d3',c4',d4',c5',d5',c6',d6',c7',d7',c8',d8',c9',d9',c10',d10']';
%--
max_addr=max(addr);
disp(max_addr);
%disp(data(1:60,1));
[r,c]=size(addr);
%fprintf('data (%d) = %d \n',54,data(54));
disp(addr(r));
%disp(data);
data_out=zeros(max_addr/2+6,1);
   % for i=1: floor(max_addr/2)
   %     data_out(i)= 0;
   % end
        for j=1:r   
            data_out(addr(j)/2+1)=data(j);
            %if addr(j)==131122
            %    fprintf('data (%d) = %d \n',j,data(j));
            %    disp(data(j-16:j+5));
            %end
          %  fprintf('%10d  :  %10d \n',addr(j),data(j));              
        end
     
[r1,c]=size(data_out);
fprintf('kich thuoc :');disp(r1); 
fprintf('Gia tri data[%d] = %d \n',r,data_out(r));
fprintf('Gia tri data_out[%d] = %d \n',r1,data_out(r1));
fprintf('dia chi data[%d] = %d \n',r,addr(r));
%--    
 %data_hex=decsign2hex_audio(data_out);
    %disp(data_hex);
    
%--    
%for k=40:63
%disp(data_out(k));
%end
   y=int16(data_out);
   x=swapbytes(y);
   shift_c_hex=dec2hex(shift_c);
   shift_d_hex=dec2hex(shift_d);
   
   x(30)=hex2dec(strcat('0',shift_d_hex,'0',shift_c_hex));
   n_mix_hex=dec2hex(n_mix);
   n_state_hex=dec2hex(n_state);
        x(31)=hex2dec(strcat('0',n_state_hex,'0',n_mix_hex));%1793;%n_mix;
   word_num_hex=dec2hex(word_num);
   shift_num_hex=dec2hex(shift_num);
   if shift_num<16
       shift_num_hex=strcat('0',shift_num_hex);
   end
   if word_num<16
       word_num_hex=strcat('0',word_num_hex);
   end
   x32=strcat(shift_num_hex,word_num_hex);
        x(32)=hex2dec(x32);%3850;%word_num;
     
      %disp(x(30));
      %disp(x(31));
      %disp(x(32));
    disp(strcat(output_path,filename));
   fid=fopen(strcat(output_path,filename),'w');
   fwrite(fid,x,'short');
   fclose(fid);
  
%--    

fprintf('COMPLETED...\n');
end

