function HMM_auto_GUI(data,lib,model_path,n_state,n_mix)

%Last update: 25/7/2012
 
  M = n_mix;          %Number of mixtures 
  Q = n_state;          %Number of states 

cov_type = 'diag';

[O,T]=size(data{1});

eps=10^(-20);
prior0(1:Q,1)=eps;
prior0(1,1)=1-(Q-1)*eps;
%transmat0 = mk_stochastic(rand(Q,Q));
transmat0(1:Q,1:Q)=eps;
for i=1:(Q-1)
    transmat0(i,i)=0.8;
    transmat0(i,i+1)=1-transmat0(i,i)-(Q-2)*eps;
end
transmat0(Q,Q)=1-(Q-1)*eps;
%transmat0(1,1)=1-(Q-1)*eps;
fprintf(' khoi tao: \n');


%############     khoi tao EM dung K-mean  ###########
fprintf('khoi tao\n');
if 0
  Sigma0 = repmat(eye(O), [1 1 Q M]);
  % Initialize each mean to a random data point
  indices = randperm(T*nex);
  mu0 = reshape(data(:,indices(1:(Q*M))), [O Q M]);
  mixmat0 = mk_stochastic(rand(Q,M));
else
  [mu0, Sigma0] = mixgauss_init_cell_ASR(Q*M, data, cov_type);
  mu0 = reshape(mu0, [O Q M]);
  Sigma0 = reshape(Sigma0, [O O Q M]);
  mixmat0 = mk_stochastic(rand(Q,M));
  %khoi tao bang doan tren
end

  %##################     tinh toan   A,pi,u, sigma,   ##############

 
fprintf('\n tinh toan \n');

[LL, prior1, transmat1, mu1, Sigma1, mixmat1] = ...
 mhmm_em_cell(data, prior0, transmat0, mu0, Sigma0, mixmat0, 'max_iter', 5);
 
loglik = mhmm_logprob2(data, prior1, transmat1, mu1, Sigma1, mixmat1);
%figure(100);
disp(LL);
%plot(LL);

%##################     save cac ket qua vao thu muc   ##############

word.prior=prior1;
word.transmit=transmat1;
word.mu=mu1;
word.sigma=Sigma1;
word.mixmat=mixmat1;


fprintf('lib = %d \n',lib);
    switch lib
       case 1
           filename='khong';
       case 2
           filename='mot';
       case 3
           filename='hai';
       case 4
           filename='ba';
       case 5
           filename='bon';
       case 6
           filename='nam';
       case 7
           filename='sau';
       case 8
           filename='bay';
       case 9
           filename='tam';
       case 10
           filename='chin';
       case 11
        filename='goi';
    case 12
        filename='towi';
    case 13
        filename='lui';
    case 14
        filename='duwng';
    case 15
        filename='chay';
    case 16
        %filename='thoat';
        filename='dduwng';
    case 17
        filename='trai';
    case 18
        filename='phai';
    case 19
        filename='duoi';
    case 20
        filename='tren';
        case 21
           filename='den';
       case 22
           filename='quat';
   end

disp (filename);
output_path=strcat(model_path,filename);
save (output_path, 'word');
disp(output_path);

end