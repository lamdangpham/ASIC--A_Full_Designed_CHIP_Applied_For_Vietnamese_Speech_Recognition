function [loglikelihood, init_pi, a, mu, sigma, mixmat] = TrainHMMContinuous(NumericalData, n_states, n_mixtures)

%% 
%% FUNCTION
%% [loglikelihood, init_pi, a, mu, sigma, mixmat] = TrainHMMContinuous(NumericalData, n_states, n_mixtures)
%% Implements scaled  Baum-Welch training for continuous-observation HMMs, for the case of l-dimensional observations
%% (l-dimensional feature vectors). It is assumed that the observation pdf at each state
%% is a Gaussian mixture.
%% INPUT:
%% NumericData:    vector of cells, where each cell contains a sequence of l-dimensional feature vectors
%% n_states   :    number of states of trained HMM 
%% n_mixtures :    number of mixtures
%%                   
%% OUTPUT:                 
%% init_pi       :    vector of initial state probalities at the output of the training stage.
%% loglikelihood :    vector, each element of which contains the sum of scaled recognition probabilities of all observation sequences at each iter.
%% a             :    trainsition matrix at the output of the training stage 
%% mu            :    mu(:,:,i) mean vector of n_states states at the i-th mixture
%% sigma         :    sigma(:,:,i,j) sigma matrix at state i-th and mixture j-th
%% mixmat        :    mixmat(i,j) mixmat at i-th state and j-th mixture   
%%

threshold = 1;

previous_loglik = -inf; 
loglikelihood = [];

converged = 0; 

iter = 1; 
maxIter = 300;


numex = length(NumericalData);

l = size(NumericalData{1},1);

s = [];
 
for i = 1:length(NumericalData)
    s = [s NumericalData{i}];
end

% init_pi = normalise(rand(n_states,1));
% 
% a = normalize_structure(rand(n_states,n_states));

eps = 10^(-20);
init_pi(1:n_states,1) = eps;
init_pi(1,1)= 1 - (n_states-1)*eps;

a(1:n_states,1:n_states) = eps;
for i=1:(n_states-1)
    a(i,i) = 0.8;
    a(i,i+1) = 1 - a(i,i)-(n_states-2)*eps;
end
a(n_states,n_states) = 1 - (n_states - 1)*eps;

[mu, sigma] = mixgauss_initialize(n_states*n_mixtures, s);
mu = reshape(mu, [l n_states n_mixtures]);
sigma = reshape(sigma, [l l n_states n_mixtures]);

mixmat = normalize_structure(rand(n_states,n_mixtures));

while (iter <= maxIter) && (~converged)
    %% 
    %% E-Step
    a_loop = zeros(n_states,n_states);
    pi_loop = zeros(n_states,1);
    mixmat_loop = zeros(n_states,n_mixtures);
    first_argument = zeros(l,n_states,n_mixtures);
    second_argument = zeros(l,l,n_states,n_mixtures);
    
    loglik = 0;
    
    for ex=1:numex
        obs = NumericalData{ex};
        T = size(obs,2);
        
        [B1, B2] = mixgauss_prob(obs, mu, sigma, mixmat);

        scale = ones(1,T);

        current_loglik = 0;

        alpha = zeros(n_states,T);
        gamma = zeros(n_states,T);
        
        a_trained = zeros(n_states,n_states);

        %%% Forwards : Compute alpha %%%
        alpha(:,1) = init_pi(:) .* B1(:,1);
        [alpha(:,1), scale(1)] = normalise(alpha(:,1));

        for t=2:T 
            m_temp = a' * alpha(:,t-1);
   
            alpha(:,t) = m_temp(:) .* B1(:,t);
            [alpha(:,t), scale(t)] = normalise(alpha(:,t));
        end
        
        if any(scale==0)
            current_loglik = -inf;
        else
            current_loglik = sum(log(scale));
        end

        %%% Backwards : Compute beta %%%

        beta = zeros(n_states,T);
        
        num = size(mixmat, 2);
        gamma2 = zeros(n_states,num,T);

        beta(:,T) = ones(n_states,1);
        gamma(:,T) = normalise(alpha(:,T) .* beta(:,T));
            
        denom = B1(:,T) + (B1(:,T)==0); 
        gamma2(:,:,T) = B2(:,:,T) .* mixmat .* repmat(gamma(:,T), [1 num]) ./ repmat(denom, [1 num]);
        
        for t=T-1:-1:1
            b = beta(:,t+1) .* B1(:,t+1);
            
            beta(:,t) = a * b;
            
            beta(:,t) = normalise(beta(:,t));
        
            gamma(:,t) = normalise(alpha(:,t) .* beta(:,t));
            
            a_trained = a_trained + normalise(a .* (alpha(:,t) * b'));
             
            denom = B1(:,t) + (B1(:,t)==0);
            gamma2(:,:,t) = B2(:,:,t) .* mixmat .* repmat(gamma(:,t), [1 num]) ./ repmat(denom,  [1 num]);      
        end
        
        %%
        
        loglik = loglik + current_loglik;
        
        a_loop = a_loop + a_trained;
        pi_loop = pi_loop + gamma(:,1);
        
        mixmat_loop = mixmat_loop + sum(gamma2,3);
        
        for i=1:n_states
            for k=1:n_mixtures
                w = reshape(gamma2(i,k,:), [1 T]); 
                wobs = obs .* repmat(w, [l 1]); 
                first_argument(:,i,k) = first_argument(:,i,k) + sum(wobs, 2);
                second_argument(:,:,i,k) = second_argument(:,:,i,k) + wobs * obs'; 
            end
        end
    end
    
    %%
    %% M-Step
    init_pi = normalise(pi_loop);
    a = normalize_structure(a_loop);
    mixmat = normalize_structure(mixmat_loop);
    [mu2, sigma2] = mixgauss_m(mixmat_loop, first_argument, second_argument);
    mu = reshape(mu2, [l n_states n_mixtures]);
    sigma = reshape(sigma2, [l l n_states n_mixtures]);
    fprintf(1, 'Step : %d, log likelihood = %f\n', iter, loglik);
    iter =  iter + 1;
    converged = is_converged(loglik, previous_loglik, threshold);
    previous_loglik = loglik;
    loglikelihood = [loglikelihood loglik];
end

loglikelihood


function [A,B] = normalize_structure(A)

if (ndims(A)==2) & (size(A,1)==1 | size(A,2)==1) % isvector
    [A,B] = normalise(A);
elseif ndims(A)==2 % matrix
    B = sum(A,2); 
    S = B + (B==0);
    norm = repmat(S, 1, size(A,2));
    A = A ./ norm;
else % multi-dimensional array
    ns = size(A);
    A = reshape(A, prod(ns(1:end-1)), ns(end));
    B = sum(A,2);
    S = B + (B==0);
    norm = repmat(S, 1, ns(end));
    A = A ./ norm;
    A = reshape(A, ns);
end

function [mu, sigma, weights] = mixgauss_initialize(M, data)

[d T] = size(data);
data = reshape(data, d, T); % in case it is data(:, t, sequence_num)

C = cov(data');
sigma = repmat(diag(diag(C))*0.5, [1 1 M]);

% Initialize each mean to a random data point
indices = randperm(T);
mu = data(:,indices(1:M));
weights = normalise(ones(M,1));

function [mu, sigma] = mixgauss_m(w, first_argument, second_argument)
		
[Ysz Q] = size(first_argument);

cov_prior = repmat(0.01*eye(Ysz,Ysz), [1 1 Q]);

second_argument = reshape(second_argument, [Ysz Ysz Q]);

w = w + (w==0);

mu = zeros(Ysz, Q);
for i=1:Q
    mu(:,i) = first_argument(:,i) / w(i);
end

sigma = zeros(Ysz,Ysz,Q);
for i=1:Q
    SS = second_argument(:,:,i)/w(i) - mu(:,i)*mu(:,i)';
    sigma(:,:,i) = SS;
end

sigma = sigma + cov_prior;

function [converged] = is_converged(loglik, previous_loglik, threshold)

check_increased = 1;

converged = 0;

if check_increased
    if loglik < previous_loglik
        converged = 1;
        return;
    end
end

if abs(loglik - previous_loglik) < threshold 
    converged = 1; 
end
