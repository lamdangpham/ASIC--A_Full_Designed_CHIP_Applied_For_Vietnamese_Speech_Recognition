function training_HMM(data,lib,output_model_path,n_states,n_mixtures)
switch lib
  case 1 
    word='khong';
  case 2 
    word='mot';    
  case 3 
    word='hai';    
  case 4 
    word='ba';    
  case 5 
    word='bon';    
  case 6 
    word='nam';    
  case 7 
    word='sau';    
  case 8 
    word='bay';    
  case 9
    word='tam';    
  case 10 
    word='chin';    
  case 11 
    word='lich';    
  case 12 
    word='su';    
  case 13 
    word='van';    
  case 14 
    word='hoas';    
  case 15 
    word='giao';    
  case 16 
    word='duc';    
  case 17 
    word='khoa';    
  case 18 
    word='hoc';    
  case 19 
    word='nong';    
  case 20 
    word='nghiep';    
  case 21 
    word='ca';    
  case 22 
    word='heo';    
  case 23 
    word='ga';    
  case 24 
    word='vit';    
  case 25 
    word='suc';    
  case 26 
    word='khoe';    
  case 27 
    word='cay';    
  case 28 
    word='hoa';  
    %word='di';    
  case 29 
    word='bat';    
  case 30 
    word='tat';    
  case 31 
    word='mo';    
  case 32 
    word='dong';    
  case 33 
    word='den';    
  case 34 
    word='quat';    
  case 35 
    word='cua';    
  case 36 
    word='phong';    
  case 37 
    word='khach';    
  case 38 
    word='ngu';    
  case 39 
    word='bep';  
    %word='len';    
  case 40 
    word='dung';    
  case 41 
    word='bo';    
  case 42 
    word='qua';    
  case 43 
    word='tiep';  
    %word='toi';    
  case 44 
    word='tuc';  
    %word='lui';    
  case 45 
    word='toi';  
    %word='tooi';    
  case 46 
    word='nghe';    
  case 47 
    word='muon';    
  case 48
    word='tin';
    %word='xuong';    
  case 49 
    word='chao';    
  case 50 
    word='ban';       
end

%% Training
[loglikelihood, init_pi, a, mu, sigma, mixmat] = TrainHMMContinuous(data, n_states, n_mixtures);
model.prior=init_pi;
model.transmit=a;
model.mu=mu;
model.sigma=sigma;
model.mixmat=mixmat;
modelpath=[output_model_path,'\',word,'.mat'];
save(modelpath,'model');
end
