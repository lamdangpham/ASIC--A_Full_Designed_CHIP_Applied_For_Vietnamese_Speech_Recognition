1/ main_flow_v2.m : Khoi Giai Ma O quy trinh Nhan Dang Giong y Chang Phan Cung
     | 
     |-GCU_HW.m                  : T�nh To�n X�c Su�t Cho M�t Trang Thai
     | 
     |-Viterpi_1_point_HW.m      : Tinh Giai Thuat Viterbi


2/Conv_mfcc_HW.m : Chuyen ma tran MFCC mfcc_numxframe_num thanh ma tran 1 cot chua tat ca cac MFCC cua mot mau
                   Trong do cu 32 hang la 1 MFCC, Neu MFCC chi co 26 phan tu thi 27-->32 se la 0
                   File nay se duoc goi truoc de dinh dang lai format ma tran MFCC truoc khi "main_flow_v2.m" duoc goi

                   
3/Convert_model_HW_v2 ---> convert_one_model_HW_v2.m : File nay convert model tu huan luyen cua anh Loc (thu muc: HMM training Mr Loc prj)
                                                       Thanh mo hinh Small hardware (Dung mot phan cua Flash --> 64 tu, 8 trang thai, 4 bo tron, 32 MFCC)

                   
4/Convert_model_HW_v3 ---> convert_one_model_HW.m :    File nay convert model tu huan luyen cua anh Loc (thu muc: HMM training Mr Loc prj)
                                                       Thanh mo hinh FUll hardware (Dung toan bo Flash --> 1024 tu, 16 trang thai , 4 bo tron , 32 MFCC)
   
   
                     