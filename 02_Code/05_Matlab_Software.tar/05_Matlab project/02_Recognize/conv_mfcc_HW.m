function [ mfcc_out ] = conv_mfcc_HW(mfcc_in)
   %mfcc_in: mean_num*number 
   [M,N]=size(mfcc_in);
   mfcc_out=reshape([mfcc_in;zeros(32-M,N)],32*N,1); % ham reshape chuyen dang ma tran nay sang dang ma tran khac
end
%{ 
  EXAMPLE:
  1 mau co 4 frame , 1 frame tuong ung 1 vector MFCC gom 26 phan tu
  Sau khi mau duoc tric dac trung se tra ve mot ma tran 26x4  gom 26 hang voi moi hang la 1 dac trung, 4 cot voi moi cot tuong ung 1 frame
  Trong phan cung viec ghi len MFCC memory duoc mo ta va matching voi phan mem . Do do cach luu tru 16x4 khong phu hop va chuyen thanh kieu sau:
  Luu tren ma tran 1 cot va 32x4 hang. Nhu vay cu 32 gia tri la chua 1 vector MFCC tuong ung 1 frame (cac gia tri 27 --> 32 se duoc dien 0).
  32 hang ke tiep se la vector MFCC cho frame ke tiep va cu vay keo dai cho den khi cover het so frame cua mau   
%} 