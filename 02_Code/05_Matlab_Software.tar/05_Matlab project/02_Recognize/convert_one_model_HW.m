function [data_out]=convert_one_model_HW(model,sequence_number,model_type,data_in,word_num,state_num,mix_num,mean_num)
%{
Written by THT, 7/4/2014
Modified bt THT, 10/7/2014 
This program is written to convert 1 model of HMM from matlab format to 
txt_binary format to export to HW
input: model: our model
       sequence_number: number of that model (=wn)
       model_type: this model is indepence or not('dependence' or 'independence'), if 'independence' then all the following parameters belong to indepence
       word_num: number of word, max = 512 (include 128 indepence words)
       state_num: number of state, max = 16
       mix_num: number of mixture, max = 8
       mean_num: number of mean value(=number of MFCC), max =30
       data_in: previous data which will be add in this program
%}
SHIFTCD=10;
%%
%%%%%%%%%%%Take values %%%%%%%%%%%%%%%
A=model.transmit;
mixmat=model.mixmat;
sigma=model.sigma;
%Don't take pi matrix
mu=model.mu;
[d Q M] = size(mu);
%d=mean_num Q=state_num M=mix_num 

%%
%%%%%%%%%%%Convert to HW values, preparing for creating%%%%%%%%%%%%
%%%%%%%transmit
for i=1:Q
  for j=1:Q
    if A(i,j) ==0
      A(i,j)=2^(-1000);
    end
  end
end
A=floor(log(A)*2^5);
for i=1:Q-1
  A_conv(i,1)=A(i,i+1)-A(i,i);
  A_conv(i,2)= -A(i,i);
end
A_conv(Q,1)=0;
A_conv(Q,2)= -A(Q,Q);

%%%%%%%mu
mu_conv=-floor(mu);

%%%%%%%sigma
for j=1:Q
  for k=1:M
    for i=1:d
      sig(i,j,k)=sigma(i,i,j,k); %just use the diag of sigma
    end
  end
end
sig_conv=floor(-1/sig*2^8);
for j=1:Q
  for k=1:M
    for i=1:d
      if sig_conv(i,j,k)<=-25600
        sig_conv(:,j,k)=-32;
      end    
    end
  end
end

%%%%%%%mixmat
detSig=ones(1,Q,M);
for i=1:d
  detSig=detSig(1,:,:).*sig_conv(i,:,:);
end
MS=sqrt((2*pi)^d*detSig);
MS=reshape(MS,state_num,mix_num);
C=mixmat(:,:)./MS;
lnC_conv=floor(log(C));

%%
%%%%%%%%%%%%%Put values in order%%%%%%%%%%%%%%%
%export=zeros(2^22+4,1);
export=data_in;

%%%%%%put mean, cov and lnC values to export
wn=sequence_number;
if strcmp(model_type,'dependence')
  wn_bin=['0',dec2bin(wn-1,9)];
elseif strcmp(model_type,'independence')
  %dong code nay de chuyen tu so thu tu 47 48 49 50 thanh 1 2 3 4, sau khi
  %da co bo tu vung day du => bo dong nay
  wn=wn-46;
  %%%%%%%%%%%%%%%%
  wn_bin=['11',dec2bin(wn-1,8)];
end
%wn_bin=dec2bin(wn-1,8);
for sn=1:Q
  sn_bin=dec2bin(sn-1,4);
  for mn=1:M
    mn_bin=dec2bin(mn-1,2);  
    add=bin2dec(['0',wn_bin,sn_bin,mn_bin,'000000']);
    for j=1:d
      add_write=add+(2*j-1);
      %mean values
      export(add_write,1)=mu_conv(j,sn,mn);
      %cov values
      export(add_write+1,1)=sig_conv(j,sn,mn);
    end
    export(add+d*2+1,1)=lnC_conv(sn,mn);
    export(add+d*2+2,1)=A_conv(sn,2);
  end  
end

%%%%%%put A 
%%%%Aij-Aii
add=bin2dec(['1',wn_bin,'1000','00','000000'])+1;
export(add:add+Q-2)=A_conv(1:Q-1,1);
%export(add+(Q-1)*(wn-1):add+Q-2+(Q-1)*(wn-1))=A_conv(1:Q-1,1);
%%%%-Aii
add=bin2dec(['1',wn_bin,'0100','00','000000'])+1;
export(add:add+Q-1)=A_conv(:,2);
%export(add+Q*(wn-1):add+Q-1+Q*(wn-1))=A_conv(:,2);


%%%%%%put parametter
add=2^22+1;
if strcmp(model_type,'dependence')  %if this is normal model
  export(add,1)=word_num;
  export(add+1,1)=state_num;
  export(add+2,1)=mix_num;
  export(add+3,1)=mean_num;
elseif strcmp(model_type,'independence') %if this is independent model
  export(add+4,1)=word_num;
  export(add+5,1)=state_num;
  export(add+6,1)=mix_num;
  export(add+7,1)=mean_num;
end   
export(add+8,1)=SHIFTCD;

%%%%%%export
data_out = export;
%cellstr(dec2hex((export<0)*2^16+export));
%fid=fopen(path_out,'w');
%fprintf(fid,'%s\n',data{:});
end
