function [ result ] = main_flow_v2( data_in, x_mfcc, start, finish, model_type, RAM_type)
%This function computes the probability of sequent observations which are contained in mfcc by HW style 
%input: 
%  + data_in: model parameters  da luu dung theo phan cung quy dinh
%  + x_mfcc: mfcc (Ma tran 1 cot n hang --> 32 hang la 1 MFCC) luu dung theo phan cung quy dinh
%  + start  : Tu nhan dang dau tien
%  + finish : Tu nhan dang ket thuc
%  + model_type: dependence / independence
%  + RAM_type: Using small/Full FLASH   
%output:probability of x_mfcc, 

%01_Get the mfcc number = frame number
mfcc_number=length(x_mfcc)/32;

%02_Create initial value for register
reg_mfcc=zeros(32,8);

%03_Get model's information as state load word/mix/mean/aij_ii/aii as in hardware
if strcmp(RAM_type,'small')  
  add=2^17+1; % Using Small FLASH --> bits 18-->22 = 0
  if strcmp(model_type,'dependence')
    word_num=data_in(add,1);
    state_num=data_in(add+1,1);
    mix_num=data_in(add+2,1);
    mean_num=data_in(add+3,1);  
  elseif strcmp(model_type,'independence')
    word_num=data_in(add+4,1);
    state_num=data_in(add+5,1);
    mix_num=data_in(add+6,1);
    mean_num=data_in(add+7,1);    
  end  
elseif strcmp(RAM_type,'full')  
  add=2^22+1;  % Using FULL Flash --> bit 22 is information of system (=1) or contain mean & cov (=0)
  if strcmp(model_type,'dependence')
    word_num=data_in(add,1);
    state_num=data_in(add+1,1);
    mix_num=data_in(add+2,1);
    mean_num=data_in(add+3,1);   
  elseif strcmp(model_type,'independence')
    word_num=data_in(add+4,1);
    state_num=data_in(add+5,1);
    mix_num=data_in(add+6,1);
    mean_num=data_in(add+7,1);      
  end  
end
reg_state=zeros(2^mix_num-1,1);
prob=zeros(word_num,1);

%04_Start recognition
for wn=start:finish   %Bat dau tu dau tien --> tu ket thuc (setup dieu nay tren GUI)
  if strcmp(RAM_type,'small')  
    if strcmp(model_type,'dependence')
      wn_bin=dec2bin(wn-1,6);                 %So thu tu cua tu dua tren start va finish no se dem len
    elseif strcmp(model_type,'independence')
      wn_bin=['111',dec2bin(wn-1,3)];
    end
  elseif strcmp(RAM_type,'full')
    if strcmp(model_type,'dependence')
      wn_bin=['0',dec2bin(wn-1,9)];
    elseif strcmp(model_type,'independence')
      wn_bin=['11',dec2bin(wn-1,8)];
    end
  end   

  time=1;
  bjot=zeros(mfcc_number,state_num);   %containt bjot of all mfcc at all state
  
  %04_01: Loop MFCC number/8 
  for i=1:ceil(mfcc_number/8)
    %Tinh toan so lan lap tinh toan GCU --> THong thuong thi maxt=8 --> Nhung tong frame khong chia het cho 8 thi maxt se nho hon 8 o lan tinh cuoi cung 
    if (i==ceil(mfcc_number/8))
      maxt=mod(mfcc_number,8)+(mod(mfcc_number,8)==0)*8;
    else maxt=8;
    end
	
	%04_02: Loop State num  
    for sn=1:state_num  
	  %Lay cac gia tri Aij_ii; Aii; Dia chi Address bat dau 
      if strcmp(RAM_type,'small')  
        sn_bin=dec2bin(sn-1,3);
        %%%%%%load data to reg   
        add=bin2dec(['0',wn_bin,sn_bin,'00','000000'])+1;
        reg_state=data_in(add:add+255,1);%parameter of 1 state
        add=bin2dec(['1',wn_bin,'100','00','000000'])+1;
        Aij_Aii=data_in(add:add+state_num-2);
        add=bin2dec(['1',wn_bin,'010','00','000000'])+1;
        Aii=data_in(add:add+state_num-1);  
      elseif strcmp(RAM_type,'full')
        sn_bin=dec2bin(sn-1,4);
        %%%%%%load data to reg   
        add=bin2dec(['0',wn_bin,sn_bin,'000','000000'])+1;
        reg_state=data_in(add:add+511,1);%parameter of 1 state
        add=bin2dec(['1',wn_bin,'1000','000','000000'])+1;
        Aij_Aii=data_in(add:add+state_num-2);
        add=bin2dec(['1',wn_bin,'0100','000','000000'])+1;
        Aii=data_in(add:add+state_num-1);
      end 
	  
      %04_03_01: Loop tinh 8 GCU cho moi lan for  	  
      for t=1:maxt   %Thong thuong thi maxt = 8 nhung neu den cac frame cuoi maxt co the nho hon 8  
        %%%taking one mfcc
        reg_mfcc=x_mfcc((8*(i-1)+t-1)*32+1:(8*(i-1)+t-1)*32+mean_num); 
        %%% computing bjot
        bjot(time,sn)=GCU_HW(reg_mfcc,reg_state,word_num,state_num,mix_num,mean_num);
        time=time+1;
      end
      time=time-maxt;%reset time
	  
      %%%%%%%Viterpi searching
	  %04_03_02: Giai thuat viterbi cu moi lan 8 GCU duoc tinh xong 
      for t=1:maxt  
        if time==1
          bjot(time,sn)=Viterpi_1_point_HW(time, sn,bjot(time,sn));
        elseif ((time>1)&&(sn==1))
          bjot(time,sn)=Viterpi_1_point_HW(time, sn,bjot(time,sn),bjot(time-1,sn));   
        elseif ((time>1)&&(sn>1))
          bjot(time,sn)=Viterpi_1_point_HW(time, sn,bjot(time,sn),bjot(time-1,sn),bjot(time-1,sn-1),Aij_Aii(sn-1,1));         
        end
        if (time == 9) && (sn == 1)  
          bjot(time,sn);
        end
        time=time+1;
      end
	  
      if sn<state_num
        time=time-maxt; %reset time if sn <state_num
      end
    end % end of state number
  end % end of mfcc number
  bjot(time-1,:)=bjot(time-1,:)+Aii';
  prob(wn,1)=max(bjot(time-1,:));
end % end of word number
prob'
prob_final=max(prob);

%05_Chon tu matching voi xac suat cuoi cung
for wn=1:word_num
  if prob(wn,1)==prob_final  % Ma tran Prob luu tru tuan tu 50 xac suat tinh duoc tu vong for (start --> finish) o tren.  
    break;                   % Vay xac suat thu n nao trung voi xac suat lon nhat "prob_final" se la tu nhan dang thu n  
  end
end
result=wn;
end


