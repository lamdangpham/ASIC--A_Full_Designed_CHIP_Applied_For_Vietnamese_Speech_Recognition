function [prob] = Viterpi_1_point_HW(t, j, otsj, ot_1sj, ot_1sj_1, a)
%Viterpi_1_point_HW: this function is writed for computing the propability
%of a observation at a state in regard to Viterpi algorithm
%input: otsj: bj(ot) of observer ot at state j
%       ot_1sj: bj(ot) of observer o(t-1) at state j
%       ot_1sj_1: bj(ot) of observer o(t-1) at state j-1
%       t, j
%       a=a(j-1)(j)-a(j-1)(j-1) 
if (t==1)     % Cho cot dau tien nhu hinh trong hardware
  prob=otsj;
else
  if (j==1) % Cho hang dau tien 
    prob=otsj+ot_1sj;  
  else  % Cho cac truong hop khac con lai
    if (ot_1sj<(ot_1sj_1+a))
      prob = otsj + ot_1sj_1+a;
    else
      prob = otsj + ot_1sj;  
    end
  end
end

