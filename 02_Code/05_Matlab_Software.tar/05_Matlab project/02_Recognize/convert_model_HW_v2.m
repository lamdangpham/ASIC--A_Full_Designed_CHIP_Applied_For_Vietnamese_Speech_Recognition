function convert_model_HW_v2(path_in,path_out,word_num,word_num_ind,state_num,mix_num,mean_num,name,txt)
%%%%%%%this code, when working with "convert_one_model_HW" can convert a
%group of models into 1 file which contain HW data of them.

%%%%%%%%%%%load model  %%%%%%%%%%%%%%%
for wn=1:word_num
  wn  
  switch wn
    case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
    case 5 
      word='bon';    
    case 6 
      word='nam';    
    case 7 
      word='sau';    
    case 8 
      word='bay';    
    case 9
      word='tam';    
    case 10 
      word='chin';    
    case 11 
      word='lich';    
    case 12 
      word='su';    
    case 13 
      word='van';    
    case 14 
      word='hoas';    
    case 15 
      word='giao';    
    case 16 
      word='duc';    
    case 17 
      word='khoa';    
    case 18 
      word='hoc';    
    case 19 
      word='nong';    
    case 20 
      word='nghiep';    
    case 21 
      word='ca';    
    case 22 
      word='heo';    
    case 23 
      word='ga';    
    case 24 
      word='vit';    
    case 25 
      word='suc';    
    case 26 
      word='khoe';    
    case 27 
      word='cay';    
    case 28 
      %word='di';    
      word='hoa';
    case 29 
      word='bat';    
    case 30 
      word='tat';    
    case 31 
      word='mo';    
    case 32 
      word='dong';    
    case 33 
      word='den';    
    case 34 
      word='quat';    
    case 35 
      word='cua';    
    case 36 
      word='phong';    
    case 37 
      word='khach';    
    case 38 
      word='ngu';    
    case 39 
      %word='len';
      word='bep';
    case 40 
      word='dung';    
    case 41 
      word='bo';    
    case 42 
      word='qua';    
    case 43 
      %word='toi';
      word='tiep';
    case 44 
      %word='lui';
      word='tuc';
    case 45 
      %word='tooi';
      word='toi';
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      %word='xuong';
      word='tin';
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end 
  load([path_in,'/',word,'.mat']);
  if wn==1
    export_data=zeros(bin2dec(['11111111','0000000000'])+state_num,1);  
    export_data=convert_one_model_HW_v2(model,wn,'no',export_data,word_num,word_num_ind,state_num,mix_num,mean_num);
  elseif (wn~=1)
    export_data=convert_one_model_HW_v2(model,wn,'no',export_data,word_num,word_num_ind,state_num,mix_num,mean_num);
  end
end

for wn=1:word_num_ind
  wn  
  switch wn
    case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
  end
  load([path_in,'/',word,'.mat']);
  export_data=convert_one_model_HW_v2(model,wn,'yes',export_data,word_num,word_num_ind,state_num,mix_num,mean_num);
end

%export to m file
path_export=[path_out,'/',name,'.mat'];
save(path_export,'export_data');

%export to txt file
if strcmp(txt,'yes')
  path_export=[path_out,'/',name,'.txt'];
  model_convert=cellstr(dec2hex((export_data<0)*2^16+export_data));
  fid=fopen(path_export,'wt');
  fprintf(fid,'%s\n',model_convert{:});
  fclose('all');
end
end