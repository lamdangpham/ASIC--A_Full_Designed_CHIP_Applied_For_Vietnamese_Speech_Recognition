function [ xlout ] = GCU_HW(i_data_mfcc, i_data_state, word_num, state_num, mix_num, mean_num)
%GCU module to calculate Bjot
%input: i_data_mfcc: mfcc data: mean_num*1 (26 neu mean num bang 26)
%       i_data_state: data of 1 state, include: cov, mean, lnC, Ajj of all
%                     mixtures in each state (mean va cov cho all mixture of 1 state) 
%       ln_C: mix_num*1
%       Ajj: 1*1
%       word_num,state_num,mix_num,mean_num

for j=1:mix_num
%% take mixture data
  i_data_mu=i_data_state(64*(j-1)+1:2:64*(j-1)+1+(mean_num-1)*2,1); %mean
  i_data_sig=i_data_state(64*(j-1)+2:2:64*(j-1)+2+(mean_num-1)*2,1);%cov
  lnC=i_data_state(64*(j-1)+2+(mean_num-1)*2+1,1);
  Ajj=i_data_state(64*(j-1)+2+(mean_num-1)*2+2,1);
  osumout=0;
  
  for i=1:mean_num
%% cla16 
    ocla16=i_data_mfcc(i,1)+i_data_mu(i,1); %16 bit

%% mul16
    mulout16=ocla16*ocla16;       %32 bits
    mulout16=floor(mulout16/32);         %take bits 32-5

%% mul26
    mulout26=mulout16*i_data_sig(i,1);

%% core adder (cla 52 01)
    osumout=osumout+mulout26;
  end
%% add lnC
    mulout52_02=osumout+lnC;
%% add Ajj
    mulout52_03=mulout52_02-Ajj;
    reg(j,1)=mulout52_03; %save all prob of each mixture into this matrix
end
%% out lnC_X_max
xlout=max(reg);

