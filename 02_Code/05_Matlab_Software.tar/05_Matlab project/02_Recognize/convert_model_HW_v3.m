function convert_model_HW_v3(input_path,start,finish,word_num,n_state,n_mix,mean_num,model_type,RAM_type,situation,name)
%%%%%%%this code, when working with "convert_one_model_HW" can convert a
%group of models into 1 file which contain HW data of them.

%%%%%%%%%%%load model  %%%%%%%%%%%%%%%
flag_start=0;
for wn=start:finish
  display(wn);  
 if strcmp(model_type,'dependence')   
  switch wn
   case 1 
      word='khong';
    case 2 
      word='mot';    
    case 3 
      word='hai';    
    case 4 
      word='ba';    
    case 5 
      word='bon';    
    case 6 
      word='nam';    
    case 7 
      word='sau';    
    case 8 
      word='bay';    
    case 9
      word='tam';    
    case 10 
      word='chin';    
    case 11 
      word='lich';    
    case 12 
      word='su';    
    case 13 
      word='van';    
    case 14 
      word='hoas';   
      %word='hoa'; 
    case 15 
      word='giao';    
    case 16 
      word='duc';    
    case 17 
      word='khoa';    
    case 18 
      word='hoc';    
    case 19 
      word='nong';    
    case 20 
      word='nghiep';    
    case 21 
      word='ca';    
    case 22 
      word='heo';    
    case 23 
      word='ga';    
    case 24 
      word='vit';    
    case 25 
      word='suc';    
    case 26 
      word='khoe';    
    case 27 
      word='cay';    
    case 28 
      word='hoa';  
      %word='di';    
    case 29 
      word='bat';    
    case 30 
      word='tat';    
    case 31 
      word='mo';    
    case 32 
      word='dong';    
    case 33 
      word='den';    
    case 34 
      word='quat';    
    case 35 
      word='cua';    
    case 36 
      word='phong';    
    case 37 
      word='khach';    
    case 38 
      word='ngu';    
    case 39 
      word='bep';  
      %word='len';    
    case 40 
      word='dung';    
    case 41 
      word='bo';    
    case 42 
      word='qua';    
    case 43 
      word='tiep';  
      %word='toi';    
    case 44 
      word='tuc';  
      %word='lui';    
    case 45 
      word='toi';  
      %word='tooi';    
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      word='tin';
      %word='xuong';    
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end
 elseif strcmp(model_type,'independence')
  switch wn %tu khong phu thuoc la gi, se sua lai cho dung sau
    case 43 
      word='tiep';  
      %word='toi';    
    case 44 
      word='tuc';  
      %word='lui';    
    case 45 
      word='toi';  
      %word='tooi';    
    case 46 
      word='nghe';    
    case 47 
      word='muon';    
    case 48
      word='tin';
      %word='xuong';    
    case 49 
      word='chao';    
    case 50 
      word='ban';    
  end
 end
  display([input_path,'/',word,'.mat']); 
  load([input_path,'/',word,'.mat']);
  if flag_start==0
    flag_start=1;  
    if strcmp(RAM_type,'small')  
      if strcmp(situation,'new')   
        export_data=zeros(bin2dec(['11111111','0000000000'])+n_state,1); %khoi tao data
      elseif strcmp(situation,'add')
        path_input=[input_path,'/',name,'.mat']  
        load(path_input);   %load data co san
      end
      export_data=convert_one_model_HW_v2(model,wn,model_type,export_data,word_num,n_state,n_mix,mean_num);
    elseif strcmp(RAM_type,'full')
      if strcmp(situation,'new')    
        export_data=zeros(bin2dec(['11111111111','000000000000'])+n_state,1); %khoi tao data 
      elseif strcmp(situation,'add')
        path_input=[input_path,'/',name,'.mat']
        load(path_input);  %load data co san
      end
      export_data=convert_one_model_HW(model,wn,model_type,export_data,word_num,n_state,n_mix,mean_num);
    end  
  elseif (flag_start~=0)
    if strcmp(RAM_type,'small')  
      export_data=convert_one_model_HW_v2(model,wn,model_type,export_data,word_num,n_state,n_mix,mean_num);
    elseif strcmp(RAM_type,'full')
      export_data=convert_one_model_HW(model,wn,model_type,export_data,word_num,n_state,n_mix,mean_num);  
    end   
  end
end

%export to m file
path_export=[input_path,'/',name,'.mat'];
save(path_export,'export_data');

%export to txt file
fprintf('CONVERTING MODEL TO TXT...\n');
path_export=[input_path,'/',name,'.txt'];
model_convert=cellstr(dec2hex((export_data<0)*2^16+export_data));
fid=fopen(path_export,'wt');
fprintf(fid,'%s\n',model_convert{:});
fclose('all');
end